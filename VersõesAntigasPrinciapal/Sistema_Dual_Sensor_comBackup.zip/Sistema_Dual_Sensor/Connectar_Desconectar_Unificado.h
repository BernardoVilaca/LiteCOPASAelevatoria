#ifndef CONNECTAR_DESCONECTAR_H
#define CONNECTAR_DESCONECTAR_H

// --- Definições Globais ---
#define TINY_GSM_MODEM_SIM7600
#define TINY_GSM_RX_BUFFER 4096
#define SerialAT Serial2

// Definições de Tamanho
#define NUM_AMOSTRAS 1024    // Total coletado (RAM)
#define TAMANHO_BACKUP 256   // Total salvo no RTC (Truncado)

#include <Arduino.h>
#include <TinyGsmClient.h>
#include <SSLClient.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <esp_task_wdt.h>
#include "Certificados_MQTT.h"

// --- Tópicos MQTT Separados ---
#define TOPIC_VIBRA_REAL   "vibracao/dados"
#define TOPIC_VIBRA_BACKUP "vibracao/backup"
#define TOPIC_PRESSAO_REAL   "pressao/dados"
#define TOPIC_PRESSAO_BACKUP "pressao/backup"

// Configurações Rede
const char APN[] = "claro.com.br";
const char USER_MODEM[] = "claro";
const char PASS_MODEM[] = "claro";
#define MQTT_SERVER "150.164.102.217"
const int MQTT_PORT = 8883;
const String CLIENT_ID = "LITE_DUAL_SENSOR";
const char *MQTT_USER = "lite";
const char *MQTT_PASS = "lite123";

// Buffers JSON
static StaticJsonDocument<512> jsonSmall;
static DynamicJsonDocument jsonLarge(4096);
static char mqttMsgBuffer[4096];

TinyGsm modem(SerialAT);
TinyGsmClient modemClient(modem);
SSLClient secureClient(&modemClient);
PubSubClient client(secureClient);

typedef struct { int16_t x, y, z; } AmostraAcelerometro;

// --- Variáveis Externas (Definidas no .ino) ---
extern AmostraAcelerometro backupVals[4][TAMANHO_BACKUP]; // Matriz Vibração
extern float backupPressao[4]; // Array Pressão

// --- Funções Auxiliares ---
inline void waitMs(uint32_t ms) { vTaskDelay(pdMS_TO_TICKS(ms)); }

bool iniciarModem4G() {
    Serial.println("[MODEM] Iniciando...");
    SerialAT.setRxBufferSize(TINY_GSM_RX_BUFFER);
    SerialAT.begin(115200, SERIAL_8N1, 16, 17);
    waitMs(500);

    if (!modem.restart()) {
        Serial.println("[MODEM] Falha no Restart.");
        return false;
    }

    if (!modem.waitForNetwork(60000L)) return false;
    if (!modem.gprsConnect(APN, USER_MODEM, PASS_MODEM)) return false;

    if (modem.isGprsConnected()) {
        secureClient.setCACert(MQTT_CA);
        secureClient.setCertificate(MQTT_CE);
        secureClient.setPrivateKey(MQTT_KEY);
        return true;
    }
    return false;
}

bool conectarRedeEbroker() {
    if (!modem.isGprsConnected()) if (!iniciarModem4G()) return false;

    client.setServer(MQTT_SERVER, MQTT_PORT);
    client.setBufferSize(sizeof(mqttMsgBuffer) + 256);
    client.setKeepAlive(60);

    unsigned long t0 = millis();
    while (!client.connected()) {
        if (millis() - t0 > 30000) return false;

        char idTemp[50];
        snprintf(idTemp, sizeof(idTemp), "%s_%04X", CLIENT_ID.c_str(), (uint16_t)esp_random());

        if (client.connect(idTemp, MQTT_USER, MQTT_PASS)) return true;
        waitMs(2000);
    }
    return true;
}

void desconectarGPRS() {
    if (client.connected()) { client.disconnect(); waitMs(200); }
    modem.gprsDisconnect();
}

// (Array Raw 256 posições)
bool enviarBackupVibracao(int indiceTurno, int indiceArrayRTC) {
    jsonLarge.clear();
    jsonLarge["tipo"] = "BACKUP_RAW";
    jsonLarge["turno"] = indiceTurno;

    JsonArray dataX = jsonLarge.createNestedArray("x");
    JsonArray dataY = jsonLarge.createNestedArray("y");
    JsonArray dataZ = jsonLarge.createNestedArray("z");

    for (int i = 0; i < TAMANHO_BACKUP; i++) {
        dataX.add(backupVals[indiceArrayRTC][i].x);
        dataY.add(backupVals[indiceArrayRTC][i].y);
        dataZ.add(backupVals[indiceArrayRTC][i].z);
    }

    size_t n = serializeJson(jsonLarge, mqttMsgBuffer, sizeof(mqttMsgBuffer));

    if (client.publish(TOPIC_VIBRA_BACKUP, mqttMsgBuffer, n)) {
        client.loop();
        Serial.printf("[VIBRA] Backup turno %d enviado.\n", indiceTurno);
        return true;
    }
    return false;
}

// (Valor único)
bool enviarBackupPressao(int indiceTurno, int indiceArrayRTC) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "BACKUP_PRESSAO";
    jsonSmall["turno"] = indiceTurno;
    jsonSmall["val"] = backupPressao[indiceArrayRTC];

    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));

    if (client.publish(TOPIC_PRESSAO_BACKUP, mqttMsgBuffer, n)) {
        client.loop();
        return true;
    }
    return false;
}



// Envia Vibração Realtime Fatiada (4 partes de 256 = 1024 total)
bool enviarVibracaoRealTimeChunked(AmostraAcelerometro* bufferRaw) {
    int totalPartes = NUM_AMOSTRAS / TAMANHO_BACKUP; // 1024/256 = 4

    for (int parte = 0; parte < totalPartes; parte++) {
        jsonLarge.clear();
        jsonLarge["tipo"] = "REALTIME_FULL";
        jsonLarge["parte"] = parte + 1;
        jsonLarge["total"] = totalPartes;

        JsonArray dataX = jsonLarge.createNestedArray("x");
        JsonArray dataY = jsonLarge.createNestedArray("y");
        JsonArray dataZ = jsonLarge.createNestedArray("z");

        int inicio = parte * TAMANHO_BACKUP;
        int fim = inicio + TAMANHO_BACKUP;

        for (int i = inicio; i < fim; i++) {
            dataX.add(bufferRaw[i].x);
            dataY.add(bufferRaw[i].y);
            dataZ.add(bufferRaw[i].z);
        }

        size_t n = serializeJson(jsonLarge, mqttMsgBuffer, sizeof(mqttMsgBuffer));


        if (!client.publish(TOPIC_VIBRA_REAL, mqttMsgBuffer, n)) return false;

        client.loop();
        waitMs(150); // Delay entre pacotes
    }
    return true;
}

// Envia Pressão Realtime (Simples)
bool enviarPressaoRealTime(float medidaVolts) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "REALTIME";
    jsonSmall["val"] = medidaVolts;
    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));

    if (client.publish(TOPIC_PRESSAO_REAL, mqttMsgBuffer, n)) {
        client.loop();
        return true;
    }
    return false;
}

void iniciarDeepSleep(unsigned long tempoInicioSetup) {
    #define CICLO_MINUTOS 10
    modem.poweroff(); // Economia Crítica

    unsigned long tempoGasto = millis() - tempoInicioSetup;
    unsigned long cicloMs = CICLO_MINUTOS * 60 * 1000UL;
    unsigned long tempoDormirMs = (tempoGasto < cicloMs) ? (cicloMs - tempoGasto) : 10000UL;

    Serial.printf("[SLEEP] Dormindo %lu ms\n", tempoDormirMs);
    Serial.flush();
    esp_sleep_enable_timer_wakeup(tempoDormirMs * 1000ULL);
    esp_deep_sleep_start();
}
#endif
