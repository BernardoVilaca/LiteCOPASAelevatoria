#include <Wire.h>
#include <Adafruit_ADS1X15.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_ADXL345_U.h>
#include "esp_task_wdt.h"
#include "esp_sleep.h"
#include "Connectar_Desconectar.h"

#define WDT_TIMEOUT_MS 60000

// --- Objetos ---
SemaphoreHandle_t dataReadySemaphore;
Adafruit_ADXL345_Unified accel(12345);
Adafruit_ADS1115 ads;

// Buffers Voláteis (RAM - 1024 amostras)
AmostraAcelerometro bufferDeAmostras[NUM_AMOSTRAS];
unsigned long tempoInicioSetup;

// --- Memória RTC (Backups Separados) ---
RTC_DATA_ATTR AmostraAcelerometro backupVals[4][TAMANHO_BACKUP]; // Vibração (Truncada)
RTC_DATA_ATTR float backupPressao[4] = {0.0, 0.0, 0.0, 0.0};     // Pressão
RTC_DATA_ATTR int contBackup = 0;
RTC_DATA_ATTR int conteudo = 0;

// Controle de Turno
const int CICLOS_POR_TURNO = 36; // 6h = 36 * 10min
bool medidaImportante = false;
bool conectou = false;

// Medidas Atuais
float medidaPressaoAtual = 0.0;

void atualizaContador() {
    contBackup++;
    if (contBackup >= CICLOS_POR_TURNO) {
        medidaImportante = true;
        contBackup = 0; // Reinicia ciclo de 6h
    } else {
        medidaImportante = false;
    }
}


void enviarBackupsSeExistirem() {
    if (conteudo == 0) return;
    Serial.println("[BACKUP] Enviando pendentes...");

    bool tudoOk = true;
    for (int i = 0; i < conteudo; ++i) {
        // Tenta enviar Vibração e depois Pressão
        if (!enviarBackupVibracao(i + 1, i)) { tudoOk = false; break; }
        waitMs(200);
        if (!enviarBackupPressao(i + 1, i)) { tudoOk = false; break; }
        waitMs(200);
    }

    if (tudoOk) {
        Serial.println("[BACKUP] Limpando RTC.");
        conteudo = 0;
    }
}

void salvarBackupSeNecessario(bool sucessoEnvio) {
    if (!medidaImportante) return;
    if (sucessoEnvio) return;

    Serial.println("[RTC] Falha crítica. Salvando...");

    // Reset de Dia (Se estourar 4 turnos, limpa tudo)
    if (conteudo >= 4) {
        Serial.println("[RTC] Vetor cheio. Resetando dia...");
        conteudo = 0;
    }

    // 1. Salva Vibração (TRUNCAMENTO: Copia apenas as primeiras 256)
    for (int i = 0; i < TAMANHO_BACKUP; i++) {
        backupVals[conteudo][i] = bufferDeAmostras[i];
    }

    // 2. Salva Pressão
    backupPressao[conteudo] = medidaPressaoAtual;

    conteudo++;
    Serial.printf("[RTC] Salvo Slot %d.\n", conteudo);
}

// ============================================================
// TASKS
// ============================================================

void taskSensors(void *pv) {
    esp_task_wdt_add(NULL);

    // 1. Coleta Pressão (Média rápida)
    float somaVolts = 0;
    for(int i=0; i<5; i++) {
        int16_t adc = ads.readADC_SingleEnded(0);
        somaVolts += ads.computeVolts(adc);
        vTaskDelay(pdMS_TO_TICKS(10));
    }
    medidaPressaoAtual = (somaVolts / 5.0) - 0.0024;

    // 2. Coleta Vibração (1024 amostras)
    unsigned long lastWdt = millis();
    for (int i = 0; i < NUM_AMOSTRAS; ++i) {
        sensors_event_t e;
        accel.getEvent(&e);
        bufferDeAmostras[i].x = (int16_t)(e.acceleration.x * 100);
        bufferDeAmostras[i].y = (int16_t)(e.acceleration.y * 100);
        bufferDeAmostras[i].z = (int16_t)(e.acceleration.z * 100);

        if (millis() - lastWdt > 2000) { esp_task_wdt_reset(); lastWdt = millis(); }
        vTaskDelay(pdMS_TO_TICKS(1)); // Sync ~800Hz
    }

    xSemaphoreGive(dataReadySemaphore);
    esp_task_wdt_delete(NULL);
    vTaskDelete(NULL);
}

void taskCommunication(void *pv) {
    esp_task_wdt_add(NULL);

    if (xSemaphoreTake(dataReadySemaphore, pdMS_TO_TICKS(WDT_TIMEOUT_MS)) == pdTRUE) {

        atualizaContador();
        Serial.printf("[DADOS] Pressao: %.3f V\n", medidaPressaoAtual);

        bool sucessoEnvio = false;

        if(iniciarModem4G()){
            conectou = conectarRedeEbroker();
            if (conectou) {
                // A. Envia Backups
                enviarBackupsSeExistirem();

                // B. Envia Realtime (CHUNKING para Vibração + Pressão separada)
                bool vOK = enviarVibracaoRealTimeChunked(bufferDeAmostras);
                bool pOK = enviarPressaoRealTime(medidaPressaoAtual);

                sucessoEnvio = (vOK && pOK);

                waitMs(500);
                desconectarGPRS();
            }
            modem.poweroff();
            salvarBackupSeNecessario(sucessoEnvio);
        } else {
            salvarBackupSeNecessario(false);
            modem.poweroff();
        }

        iniciarDeepSleep(tempoInicioSetup); // Calcula tempo e dorme

    } else {
        // Erro Sensor
        esp_sleep_enable_timer_wakeup(10ULL * 1000000ULL);
        esp_deep_sleep_start();
    }
    esp_task_wdt_delete(NULL);
    vTaskDelete(NULL);
}

void setup() {
    tempoInicioSetup = millis();
    Serial.begin(115200);
    Wire.begin();
    Wire.setClock(400000);

    bool sensorsOK = true;
    if (!accel.begin()) sensorsOK = false;
    else {
        accel.setDataRate(ADXL345_DATARATE_800_HZ);
        accel.setRange(ADXL345_RANGE_16_G);
    }

    if (!ads.begin()) sensorsOK = false;
    else { ads.setGain(GAIN_ONE); }

    if(!sensorsOK) {
        esp_sleep_enable_timer_wakeup(10ULL * 1000000ULL);
        esp_deep_sleep_start();
    }

    esp_task_wdt_deinit();
    esp_task_wdt_config_t cfg = { .timeout_ms = WDT_TIMEOUT_MS, .trigger_panic = true };
    esp_task_wdt_init(&cfg);

    dataReadySemaphore = xSemaphoreCreateBinary();

    xTaskCreatePinnedToCore(taskCommunication, "TaskComms", 10000, NULL, 1, NULL, 0);
    xTaskCreatePinnedToCore(taskSensors, "TaskSensors", 8192, NULL, 2, NULL, 1);
}

void loop() { vTaskDelay(portMAX_DELAY); }
