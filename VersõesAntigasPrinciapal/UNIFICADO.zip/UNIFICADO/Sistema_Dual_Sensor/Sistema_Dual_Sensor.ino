#include <Wire.h>
#include <Adafruit_ADS1X15.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_ADXL345_U.h>
#include "esp_task_wdt.h"
#include "esp_sleep.h"
#include "Connectar_Desconectar_Unificado.h"

// --- Configurações de Timing ---
#define uS_TO_S_FACTOR 1000000
#define PRESSURE_INTERVAL 5      // 5 segundos para pressão
#define VIBRATION_INTERVAL 15    // 15 segundos para vibração

// --- Watchdog ---
#define WDT_TIMEOUT_S 20

// --- Objetos dos Sensores ---
Adafruit_ADS1115 ads;
Adafruit_ADXL345_Unified accel = Adafruit_ADXL345_Unified();

// --- Filas e Semáforos ---
QueueHandle_t pressureQueue;
SemaphoreHandle_t vibrationSemaphore;

// --- Buffer para vibração ---
#define NUM_AMOSTRAS 1024
AmostraAcelerometro vibrationBuffer[NUM_AMOSTRAS];

// --- Variáveis de Timing ---
RTC_DATA_ATTR unsigned long lastVibrationTime = 0;
RTC_DATA_ATTR unsigned long lastPressureTime = 0;

// =================================================================
// TASK DO SENSOR DE PRESSÃO (MANTIDA SUA LÓGICA ORIGINAL)
// =================================================================
void taskPressureSensor(void *pvParameters) {
    esp_task_wdt_add(NULL);
    
    while(true) {
        unsigned long currentTime = millis();
        
        // Verifica se é hora de ler a pressão
        if ((currentTime - lastPressureTime) >= (PRESSURE_INTERVAL * 1000)) {
            Serial.println("\n[PRESSURE] Iniciando leitura do ADS1115...");
            
            // Lê a tensão do canal analógico 0
            int16_t valorADC = ads.readADC_SingleEnded(0);
            float tensaoMedida = ads.computeVolts(valorADC) - 0.0024;

            Serial.printf("[PRESSURE] Tensão medida: %.4f V\n", tensaoMedida);

            // Envia para a fila
            if (xQueueSend(pressureQueue, &tensaoMedida, pdMS_TO_TICKS(1000)) != pdPASS) {
                Serial.println("[PRESSURE] FALHA: Não foi possível enviar para a fila.");
            }
            
            lastPressureTime = currentTime;
        }
        
        esp_task_wdt_reset();
        vTaskDelay(pdMS_TO_TICKS(1000)); // Delay de 1 segundo entre verificações
    }
}

// =================================================================
// TASK DO SENSOR DE VIBRAÇÃO (MANTIDA SUA LÓGICA ORIGINAL)  
// =================================================================
void taskVibrationSensor(void *pvParameters) {
    esp_task_wdt_add(NULL);
    
    while(true) {
        unsigned long currentTime = millis();
        
        // Verifica se é hora de ler vibração
        if ((currentTime - lastVibrationTime) >= (VIBRATION_INTERVAL * 1000)) {
            Serial.println("\n[VIBRATION] Iniciando coleta do ADXL345...");
            
            // Coleta as amostras (lógica original do acelerômetro)
            for (int i = 0; i < NUM_AMOSTRAS; i++) {
                sensors_event_t event;
                accel.getEvent(&event);
                vibrationBuffer[i].x = event.acceleration.x * 100;
                vibrationBuffer[i].y = event.acceleration.y * 100;
                vibrationBuffer[i].z = event.acceleration.z * 100;
                
                if (i % 100 == 0) { 
                    esp_task_wdt_reset();
                } 
            }

            Serial.println("[VIBRATION] Coleta finalizada. Notificando...");
            xSemaphoreGive(vibrationSemaphore);
            
            lastVibrationTime = currentTime;
        }
        
        esp_task_wdt_reset();
        vTaskDelay(pdMS_TO_TICKS(1000)); // Delay de 1 segundo entre verificações
    }
}

// =================================================================
// TASK DE COMUNICAÇÃO UNIFICADA
// =================================================================
void taskCommunication(void *pvParameters) {
    esp_task_wdt_add(NULL);
    float pressureData;
    
    while(true) {
        esp_task_wdt_reset();
        
        // --- Processa Dados de Pressão ---
        if (xQueueReceive(pressureQueue, &pressureData, 0) == pdPASS) {
            Serial.println("[COMM] Dados de pressão recebidos! Enviando...");
            
            connect_wifi();
            ConectarMqtt();
            esp_task_wdt_reset();
            
            sendVoltageMQTT(pressureData);
            
            esp_task_wdt_reset();
            disconnect_MQTT();
            DesconnectWifi();
            
            Serial.println("[COMM] Pressão: Ciclo completo!");
        }
        
        // --- Processa Dados de Vibração ---
        if (xSemaphoreTake(vibrationSemaphore, 0) == pdTRUE) {
            Serial.println("[COMM] Dados de vibração recebidos! Enviando...");
            
            connect_wifi();
            ConectarMqtt();
            esp_task_wdt_reset();
            
            sendRealVibrationData(vibrationBuffer, NUM_AMOSTRAS);
            
            esp_task_wdt_reset();
            disconnect_MQTT();
            DesconnectWifi();
            
            Serial.println("[COMM] Vibração: Ciclo completo!");
        }
        
        vTaskDelay(pdMS_TO_TICKS(500)); // Pequeno delay entre verificações
    }
}

// =================================================================
// SETUP PRINCIPAL
// =================================================================
void setup() {
    Serial.begin(115200);
    Serial.println("\n\n--- SISTEMA DUAL SENSOR INICIADO ---");
    Serial.println(">>> Pressão: ADS1115 | Vibração: ADXL345 <<<");

    // Inicializa Watchdog
    esp_task_wdt_init(WDT_TIMEOUT_S, true);
    
    // Inicializa Sensor de Pressão (ADS1115)
    if (!ads.begin()) {
        Serial.println("FALHA: ADS1115 não detectado! Reiniciando...");
        delay(5000);
        ESP.restart();
    }
    ads.setGain(GAIN_ONE);
    Serial.println(">>> SUCESSO: ADS1115 inicializado!");
    
    // Inicializa Sensor de Vibração (ADXL345)
    if(!accel.begin()) {
        Serial.println("FALHA: ADXL345 não detectado! Reiniciando...");
        delay(5000);
        ESP.restart();
    }
    accel.setDataRate(ADXL345_DATARATE_3200_HZ);
    accel.setRange(ADXL345_RANGE_16_G);
    Serial.println(">>> SUCESSO: ADXL345 inicializado!");

    // Cria estruturas de comunicação
    pressureQueue = xQueueCreate(5, sizeof(float));
    vibrationSemaphore = xSemaphoreCreateBinary();
    
    if (pressureQueue == NULL || vibrationSemaphore == NULL) {
        Serial.println("FALHA: Não foi possível criar estruturas de comunicação!");
        ESP.restart();
    }

    // Cria as tarefas
    xTaskCreatePinnedToCore(
        taskCommunication, "TaskCommunication", 
        12288, NULL, 1, NULL, 0
    );
    
    xTaskCreatePinnedToCore(
        taskPressureSensor, "TaskPressure", 
        4096, NULL, 2, NULL, 1
    );
    
    xTaskCreatePinnedToCore(
        taskVibrationSensor, "TaskVibration", 
        8192, NULL, 2, NULL, 1
    );
    
    Serial.println(">>> SUCESSO: Todas as tarefas iniciadas!");
    Serial.printf(">>> Timing - Pressão: %ds | Vibração: %ds\n", PRESSURE_INTERVAL, VIBRATION_INTERVAL);
}

void loop() {
    // Loop vazio - toda lógica está nas tasks
    vTaskDelay(portMAX_DELAY);
}