#ifndef CONNECTAR_DESCONECTAR_UNIFICADO_H
#define CONNECTAR_DESCONECTAR_UNIFICADO_H

#include <WiFi.h>
#include "WiFiClientSecure.h"
#include <PubSubClient.h>
#include "Certificados_MQTT.h"
#include "esp_task_wdt.h"
#include <ArduinoJson.h>

// --- T�picos MQTT ---
#define TOPIC_TENSAO   "SADUMBA/Conversor/Tensao"
#define TOPIC_VIBRACAO "vibracao/dados"

// --- Configura��es de WiFi e MQTT ---
#define MQTT_SERVER "150.164.102.217"
const int MQTT_PORT = 8883;
const char* ssid = "WIFI-LITE";
const char* password = "LITE@IOT";
const char* MQTT_USER = "lite";
const char* MQTT_PASS = "lite123";

// --- Struct para dados do aceler�metro ---
struct AmostraAcelerometro {
  int16_t x;
  int16_t y;
  int16_t z;
};

// Cliente Seguro e MQTT
WiFiClientSecure Agro_IoT;
PubSubClient client(Agro_IoT);

// --- Fun��o: Conectar WiFi ---
void connect_wifi() {
    Serial.print("\n[WIFI] Conectando a ");
    Serial.println(ssid);

    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, password);

    unsigned long startAttempt = millis();

    while (WiFi.status() != WL_CONNECTED) {
        Serial.print(".");
        delay(500);
        esp_task_wdt_reset(); // Alimenta WDT enquanto espera

        // Timeout de seguran�a se ficar travado tentando conectar
        if(millis() - startAttempt > 30000) {
            Serial.println("\n[WIFI] Falha (Timeout). Reiniciando ESP...");
            ESP.restart();
        }
    }
    Serial.println("\n[WIFI] Conectado com sucesso!");
    Serial.print("[WIFI] IP: ");
    Serial.println(WiFi.localIP());
}

// --- Fun��o: Conectar MQTT ---
void ConectarMqtt(){
    Agro_IoT.setCACert(MQTT_CA);
    Agro_IoT.setCertificate(MQTT_CE);
    Agro_IoT.setPrivateKey(MQTT_KEY);
    client.setServer(MQTT_SERVER, MQTT_PORT);
    // Aumenta buffer do cliente MQTT para suportar JSON grande
    client.setBufferSize(4096);

    while(!client.connected()){
        Serial.print("[MQTT] Conectando ao Broker... ");
        esp_task_wdt_reset();

        if(client.connect("ESP32_DualSensor_Client", MQTT_USER, MQTT_PASS)) {
            Serial.println("CONECTADO!");
        } else {
            Serial.print("Falha, rc=");
            Serial.print(client.state());
            Serial.println(" Tentando novamente em 2 segundos");
            esp_task_wdt_reset();
            delay(2000);
        }
    }
}

// --- Fun��es: Desconectar ---
void disconnect_MQTT(){
    Serial.println("[MQTT] Desconectando...");
    client.disconnect();
    Serial.println("[MQTT] Desconectado.");
}

void DesconnectWifi(){
    Serial.println("[WIFI] Desconectando...");
    WiFi.disconnect(true);
    WiFi.mode(WIFI_OFF);
    Serial.println("[WIFI] Desconectado.");
}

// --- ENVIO: Sensor de Press�o (Tens�o) ---
bool sendVoltageMQTT(float tensao) {
    char msg[100]; // Aumentado um pouco por seguran�a
    sprintf(msg, "{\"tensao\": %.4f}", tensao);

    Serial.printf("[PUBLISH] Tens�o (%s) -> %s\n", TOPIC_TENSAO, msg);

    if(!client.publish(TOPIC_TENSAO, msg)) {
        Serial.println("[ERROR] Falha na publica��o da tens�o!");
        return false;
    }
    Serial.println("[SUCCESS] Tens�o publicada!");
    return true;
}

// --- ENVIO: Sensor de Vibra��o (JSON Chunked) ---
bool sendRealVibrationData(AmostraAcelerometro samples[], int numSamples) {
    Serial.println("\n---[ ENVIO DE DADOS DE VIBRA��O ]---");

    const int CHUNK_SIZE = 60;
    int numChunks = (numSamples + CHUNK_SIZE - 1) / CHUNK_SIZE;

    // Buffer de envio
    char msgBuffer[4096];

    for (int i = 0; i < numChunks; i++) {
        esp_task_wdt_reset(); // Evita reset durante loops longos

        // CORRE��O CR�TICA: Aumentado para 3072 bytes (igual � vers�o validada)
        // Se for menor (ex: 2048), o JSON pode ser cortado e o envio falha.
        StaticJsonDocument<3072> jsonDoc;

        jsonDoc["chunk"] = (i + 1);
        jsonDoc["total_chunks"] = numChunks;
        JsonArray samplesArray = jsonDoc.createNestedArray("samples");

        int startSample = i * CHUNK_SIZE;
        int endSample = min(startSample + CHUNK_SIZE, numSamples);

        for (int j = startSample; j < endSample; j++) {
            JsonObject sample = samplesArray.createNestedObject();
            sample["x"] = samples[j].x;
            sample["y"] = samples[j].y;
            sample["z"] = samples[j].z;
        }

        size_t payloadLength = serializeJson(jsonDoc, msgBuffer, sizeof(msgBuffer));

        if (payloadLength == 0) {
            Serial.println("    >>> ERRO CR�TICO: Falha ao serializar JSON (Buffer insuficiente?)");
            continue;
        }

        Serial.printf("--> Publicando pacote de vibra��o %d de %d (%d bytes)\n", i + 1, numChunks, payloadLength);

        if (!client.publish(TOPIC_VIBRACAO, msgBuffer, payloadLength)) {
            Serial.println("    >>> ERRO: Falha na publica��o MQTT!");
            return false;
        }

        client.loop(); // Mant�m o cliente MQTT vivo
        delay(50);     // Pequeno delay para dar respiro � rede
    }

    Serial.println(">>> Todos os pacotes de vibra��o enviados!");
    return true;
}

#endif
