#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_ADXL345_U.h>
#include "esp_task_wdt.h"
#include "esp_sleep.h"

// O struct AmostraAcelerometro é definido dentro deste header
#include "Connectar_Desconectar.h"

// --- Configurações do Deep Sleep ---
#define uS_TO_S_FACTOR 1000000
#define TIME_TO_SLEEP 15

// --- Configurações do Watchdog ---
#define WDT_TIMEOUT_MS 30000 // 30 segundos

esp_task_wdt_config_t twdt_config = {
    .timeout_ms = WDT_TIMEOUT_MS,
    .trigger_panic = true,
};

// --- Transmissão de dados ---
SemaphoreHandle_t dataReadySemaphore;

// --- Configurações do ADXL345 ---
Adafruit_ADXL345_Unified accel = Adafruit_ADXL345_Unified();
#define NUM_AMOSTRAS 1024
AmostraAcelerometro bufferDeAmostras[NUM_AMOSTRAS];

// --- Task de Coleta ---
void taskDataCollector(void *pvParameters) {
  esp_task_wdt_add(NULL);
  
  // --- Coleta ---
  for (int i = 0; i < NUM_AMOSTRAS; i++) {
    sensors_event_t event;
    accel.getEvent(&event);
    bufferDeAmostras[i].x = event.acceleration.x * 100;
    bufferDeAmostras[i].y = event.acceleration.y * 100;
    bufferDeAmostras[i].z = event.acceleration.z * 100;
    
    if (i % 100 == 0) { 
      esp_task_wdt_reset();
    } 
  }

  Serial.println("Coleta finalizada. Notificando a tarefa de comunicação...");
  
  xSemaphoreGive(dataReadySemaphore);
  
  esp_task_wdt_delete(NULL);
  vTaskDelete(NULL);
}

// --- Comunicação de dados ---
void taskCommunication(void *pvParameters) {
  esp_task_wdt_add(NULL);

  while(true) {
    esp_task_wdt_reset();
    
    if (xSemaphoreTake(dataReadySemaphore, pdMS_TO_TICKS(1000)) == pdTRUE) {
      Serial.println("Tarefa de Comunicação recebeu notificação! Iniciando processo de envio...");
      
      connect_wifi();
      ConectarMqtt();
      
      unsigned long startPause = millis();
      Serial.println("Aguardando estabilização da conexão MQTT por 500ms...");
      while (millis() - startPause < 500) { 
          client.loop();
          vTaskDelay(pdMS_TO_TICKS(10));
      }
      
      sendRealVibrationData(bufferDeAmostras, NUM_AMOSTRAS);

      disconnect_MQTT();
      DesconnectWifi();

      Serial.println("\n========================================================");
      Serial.printf("Ciclo finalizado. Entrando em Deep Sleep por %d segundos...\n", TIME_TO_SLEEP);
      Serial.println("========================================================");
      Serial.flush();

      esp_sleep_enable_timer_wakeup(TIME_TO_SLEEP * uS_TO_S_FACTOR);
      esp_deep_sleep_start();
    }
  }
}

void setup() {
  Serial.begin(115200);

  if(!accel.begin()) {
    Serial.println("FALHA: ADXL345 nao detectado!");
    while (1);
  }

  Serial.println(">>> SUCESSO: Sensor ADXL345 detectado!");
  accel.setDataRate(ADXL345_DATARATE_3200_HZ);
  accel.setRange(ADXL345_RANGE_16_G);
  
  esp_task_wdt_deinit();
  esp_task_wdt_init(&twdt_config);

  dataReadySemaphore = xSemaphoreCreateBinary();

  xTaskCreatePinnedToCore(
    taskCommunication, "TaskCommunication", 16384, NULL, 1, NULL, 0
  );
  
  xTaskCreatePinnedToCore(
    taskDataCollector, "TaskDataCollector", 8192, NULL, 1, NULL, 1
  );
}

void loop() {
}