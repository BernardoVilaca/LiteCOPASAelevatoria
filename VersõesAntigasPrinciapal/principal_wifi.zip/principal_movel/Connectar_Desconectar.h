//___________________________________________________________________________________________________
//|______________Biblioteca que opera as funções de conexão e desconnexão do sistema__________________|
// (descrições das funções omitidas por brevidade)
//|___________________________________________________________________________________________________|

// -------- BIBLIOTECA JSON ADICIONADA --------
#include <ArduinoJson.h>

#include "WiFiClientSecure.h"
#include <PubSubClient.h>
#include "Certificados_MQTT.h"
#include "esp_wifi.h"                                       // API ESPRESSIF para controle chip WiFi                        //
#include <WiFi.h>
#include "esp_task_wdt.h" 
#define MQTT_MAX_PACKET_SIZE 2048
//_____________________________________________________________________________________________________________________
//_______________________________Define os tópicos a serem publicados pelo sistema_____________________________________|
#define TOPIC_ParPot "vibracao/dados"               
//_____________________________________________________________________________________________________________________|

//___________________________________________________________________________________________________________
//___________________________Defina valores e constantes relacionadas ao WiFi e MQTT_________________________|
#define MQTT_SOCKET_TIMEOUT 1                                                                          //    |
#define MQTT_VERSION MQTT_VERSION_3_1                                                                  //    |
#define MQTT_SERVER "150.164.102.217"                 //Server MQTT que iremos utilizar                //    |
const int MQTT_PORT = 8883;                           //Porta para o serVer MQTT que iremos utilizar   //    |
const String QUICK_START = "LAB IOT ";                //ID "padrão" utilizada para conectar            //    | 
const String DEVICE_ID = "Lite";                      //ID único                                       //    |
const char* ssid = "WIFI-LITE";                       // Nome da rede WiFi a ser usada                 //    |
const char* password =  "LITE@IOT";                   // Senha da rede WiFi                            //    |
const String CLIENT_ID = QUICK_START + DEVICE_ID;     //ID FINAL                                       //    |
const char * MQTT_USER = "lite";                      //Usuário criado no servidor const char          //    |
const char * MQTT_PASS = "lite123";                   //Senha respectiva ao usuário criado             //    |                        
WiFiClientSecure tlsClient;                           // Cliente WiFi (nome alterado de Agro_IoT)
PubSubClient client(tlsClient);                 //Cliente MQTT, passamos a url do server, a porta e o cliente|
struct AmostraAcelerometro {
  int16_t x;
  int16_t y;
  int16_t z;
};
//___________________________________________________________________________________________________________|

//____________________________________________________________________
//__________________Função que conecta ao WiFi________________________|
void connect_wifi()
{
    WiFi.disconnect(true);
    WiFi.mode(WIFI_OFF);
    vTaskDelay(pdMS_TO_TICKS(100)); 
    

    WiFi.mode(WIFI_STA);
    Serial.println("\n---[ ETAPA 1: Conexão Wi-Fi ]---");
    Serial.printf("Conectando à rede Wi-Fi: %s\n", ssid);


    WiFi.begin(ssid, password);
    unsigned long startTime = millis();

    while (WiFi.status() != WL_CONNECTED) {
        Serial.print(".");
        vTaskDelay(pdMS_TO_TICKS(500)); 
        
        esp_task_wdt_reset(); 
        
        if (millis() - startTime > 30000) { // Timeout de 30 segundos
            Serial.println("\nFalha ao conectar no Wi-Fi. Reiniciando...");
            vTaskDelay(pdMS_TO_TICKS(1000));
            ESP.restart();
        }
    }
    
    unsigned long tempo_conexao = millis() - startTime;
    Serial.println("\nWi-Fi CONECTADO!");
    Serial.print("Endereço IP obtido: ");
    Serial.println(WiFi.localIP());
    Serial.printf("Tempo de conexão: %lu ms\n", tempo_conexao);
}
//____________________________________________________________________|

//__________________________________________________________________________
//_______________Função que conecta ao MQTT_________________________________|
void ConectarMqtt(){
  tlsClient.setCACert(MQTT_CA); 
  tlsClient.setCertificate(MQTT_CE); 
  tlsClient.setPrivateKey(MQTT_KEY); 

  client.setBufferSize(MQTT_MAX_PACKET_SIZE); 
  client.setServer(MQTT_SERVER, MQTT_PORT);
  
  int retries = 0;
  while(client.state() != 0 && retries < 5){
    esp_task_wdt_reset(); 
    
    Serial.print("Conectando ao server MQTT ... ");
      if(client.connect("", MQTT_USER, MQTT_PASS)) {
        Serial.println("CONECTADO !");
      } 
      else {
        Serial.print("Falha, state= "); 
        Serial.print(client.state());
        Serial.println(". Tentando novamente em 2s...");
        retries++;
        

        vTaskDelay(pdMS_TO_TICKS(2000));
      }
    }

  if (client.state() != 0) {
    Serial.println("Falha ao conectar ao MQTT após 5 tentativas. Reiniciando...");

    vTaskDelay(pdMS_TO_TICKS(1000));
    ESP.restart();
  }
}
//___________________________________________________________________________|


//_______________________________________________________________
//_______________Função que desconecta do MQTT___________________|
bool disconnect_MQTT(){                                   
  Serial.println("Desconectando do MQTT...");
  client.disconnect();
        if(!client.state()==0) {
      //Se a conexão foi bem sucedida
        Serial.println("DESCONECTADO DO MQTT!");
        return true;
      } 
}
//_______________________________________________________________|

//_______________________________________________________________
//_______________Função que desconecta do WiFi___________________|
bool DesconnectWifi(){
  while (WiFi.status() == WL_CONNECTED) {
  Serial.println("Desconectando do Wi-Fi...");
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
 }
 if (WiFi.status() != WL_CONNECTED) {
  Serial.println("Desconectado com Sucesso");
  return true;
 }
}


// -------------------------------------------------------------------------------------------------------------
// --- FUNÇÃO REESCRITA COM ARDUINOJSON (Correção do Item 3) ---
// -------------------------------------------------------------------------------------------------------------
bool sendRealVibrationData(AmostraAcelerometro samples[], int numSamples)
{
    Serial.println("\n---[ ETAPA 3: Publicação de Dados com ArduinoJson ]---");
    Serial.println("------------------------------------------------------------------");

    const int CHUNK_SIZE = 60; // Seu chunk de 60 amostras
    int numChunks = (numSamples + CHUNK_SIZE - 1) / CHUNK_SIZE;

    // Buffer de serialização na stack. É mais rápido e seguro que usar 'String'
    char msgBuffer[MQTT_MAX_PACKET_SIZE];

    for (int i = 0; i < numChunks; i++) {
        esp_task_wdt_reset();

        // 1. Aloca o documento JSON na STACK.
        // Sua task 'taskCommunication' tem 16k de stack, então 3k é seguro.
        // Usar StaticJsonDocument evita 100% a fragmentação da heap.
        StaticJsonDocument<3072> jsonDoc; // Buffer de 3KB na stack para o doc JSON

        // 2. Monta a estrutura do JSON
        jsonDoc["chunk"] = (i + 1);
        jsonDoc["total_chunks"] = numChunks;
        JsonArray samplesArray = jsonDoc.createNestedArray("samples");

        int startSample = i * CHUNK_SIZE;
        // Garante que não vai ler além do fim do array
        int endSample = min(startSample + CHUNK_SIZE, numSamples); 

        // 3. Adiciona as amostras ao array JSON
        for (int j = startSample; j < endSample; j++) {
            JsonObject sample = samplesArray.createNestedObject();
            sample["x"] = samples[j].x;
            sample["y"] = samples[j].y;
            sample["z"] = samples[j].z;
        }

        // 4. Serializa o JSON para o msgBuffer
        size_t payloadLength = serializeJson(jsonDoc, msgBuffer, MQTT_MAX_PACKET_SIZE);

        if (payloadLength == 0) {
            Serial.println("    >>> ERRO: Falha ao serializar JSON!");
            Serial.println("    Talvez o StaticJsonDocument<3072> seja pequeno demais?");
            continue; // Pula para o próximo chunk
        }
        
        Serial.printf("\n--> Tentando publicar o Pacote %d de %d.\n", i + 1, numChunks);
        Serial.printf("    Tamanho do payload: %d bytes.\n", payloadLength);
        
        // 5. Publica o buffer serializado
        if (!client.publish(TOPIC_ParPot, msgBuffer, payloadLength)) {
            Serial.println("    >>> ERRO: A publicação falhou!");
            // (Seu código de verificação de status está aqui)
            int errorState = client.state();
            Serial.printf("    >>> Status da conexão DEPOIS da falha: %d\n", errorState);
            return false;
        }

        Serial.println("    >>> SUCESSO: Pacote publicado!");
        client.loop(); 

        vTaskDelay(pdMS_TO_TICKS(100));
    }

    Serial.println("\n>>> Todos os pacotes de dados foram publicados com sucesso!");
    Serial.println("------------------------------------------------------------------");
    return true;
}
//________________________________________________________________________________________________________________|