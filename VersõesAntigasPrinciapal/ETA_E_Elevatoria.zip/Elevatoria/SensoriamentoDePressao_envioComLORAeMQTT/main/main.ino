/* _______________________________ Declarção de Bilbiotecas _______________________________ */
#include <Adafruit_ADS1X15.h>  // Biblioteca do ADS1115
#include "configuration.h"     // Biblioteca de configurações do programa
#include <esp_task_wdt.h>      // Biblioteca para controle do Watchdog Timer no ESP32
//
// Bibliotecas relacionadas ao LoRa
#include <SPI.h>
#include "WiFi.h"
#include <esp_wifi.h>
#include <LoRaDeviceCSMACA.h>

/* _______________________________ Objetos _________________________________________________ */
Adafruit_ADS1115 ads;           // Objeto de funções do ADC
LoRaDevice device(GATEWAY_ID);  // Objeto de funções LoRa

/* _______________________________ Variáveis Globais _______________________________________ */
#define us_to_s_factor 1000000  //Conversion factor for micro seconds to seconds

int time_to_sleep = TIME_TO_SLEEP_NORMAL;
RTC_DATA_ATTR int CICLOS_RESTANTES_ALTERADO = 0;
RTC_DATA_ATTR float pressao_anterior = 0;
RTC_DATA_ATTR int bootCount = 0;
//
RTC_DATA_ATTR int indices_ocupados = 0;
RTC_DATA_ATTR float armazenador[medidas_armazenadas] = {};

/* _______________________________ Código Principal ______________________________________ */
void setup() {
  int inicio_codigo = millis();

  WDT_setup();

  Serial.begin(115200);  // Iniciar Serial
  delay_millis(1000);

  ++bootCount;  //Increment boot number and print it every reboot
  Serial.println("Boot number: " + String(bootCount));
  print_wakeup_reason();  //Print the wakeup reason for ESP32

  while (!ads.begin())  // Iniciar o ADS1115
  {
    Serial.println("Falha ao iniciar o ADS1115");
    delay_millis(500);
  }

  connectLoRa();
  device.showInfo();
  device.setDebug(true);  // Método que permite ou não a visualização das etapas no Mon Serial

  float tensao_parcial = 0;
  for (int i = 0; i < 10; i++) {
    float data = ads.readADC_SingleEnded(0);  // Leitura dos dados do ADS1115
    tensao_parcial = ads.computeVolts(data) + tensao_parcial;
  }

  float tensao = tensao_parcial / 10;             // Cálculo da media de tensão em V
  float pressao = 320 * tensao * 0.101974428892;  // Cálculo da pressão, considerando 5V como 1600 kPa, e fazendo a conversão para mca

  // Imprimir tensão em mV:
  Serial.print("Tensão: ");
  Serial.print(tensao * 1000);
  Serial.print(" mV");
  // Imprimir pressão em mca:
  Serial.print("  Pressão: ");
  Serial.print(pressao);
  Serial.println(" mca");

  if (bootCount != 1)  // se for a primeira medida, não vai haver variação
  {
    if (abs(pressao - pressao_anterior) > VARIACAO_PRESSAO_MAX || pressao >= PRESSAO_MAXIMA || pressao <= PRESSAO_MINIMA)  // identificar variações abruptas nas medidas
    {
      Serial.println("Condição crítica detectada!");
      time_to_sleep = TIME_TO_SLEEP_ALTERADO;
      CICLOS_RESTANTES_ALTERADO = CICLOS_ALTERADO;
    }

    if (CICLOS_RESTANTES_ALTERADO > 0) {
      CICLOS_RESTANTES_ALTERADO--;
    } else {
      time_to_sleep = TIME_TO_SLEEP_NORMAL;
    }
  }
  pressao_anterior = pressao;

  if (!sendValues(pressao)) {
    Serial.println("Erro ao enviar");
    device.alertFromGateway();

    if (indices_ocupados == medidas_armazenadas) {
      armazenador_cheio();
    }

    armazenar(pressao);
    show_armazenador();
  } else {
    Serial.println("Enviado ao broker");

    if (indices_ocupados > 0) {
      Serial.print("Enviando medidas armazenadas: ");
      show_armazenador();
      enviar_dados_armazenados();

      Serial.print("Armazenador zerado: ");
      show_armazenador();
    }
  }
  delay_millis(1000);

  esp_task_wdt_reset();  // Resetar o Watchdog Timer periodicamente para evitar o reinício
  begin_deepSleep(time_to_sleep - (millis() - inicio_codigo)/1000);
}

void loop() {}

/* ____________________________ LoRa _______________________________________________ */
void connectLoRa() {
  WiFi.begin();

  // Initialize SPI communication
  SPI.begin(SCK_LORA, MISO_LORA, MOSI_LORA, SS_PIN_LORA);

  // Set LoRa gateway pins
  device.setPins(SS_PIN_LORA, RESET_PIN_LORA, DIO0_PIN_LORA);

  // Begin LoRa device communication:
  if (!device.LoRaBegin(915E6)) Serial.println("\n[LoRa Device] Communication with LoRa radio failed");
  else Serial.println("\n[LoRa Device] Communication with LoRa radio successful");

  // Set private keys
  device.setDebug(true);

  // Sets Devices MAC
  device.setDeviceId(WiFi.macAddress());
  delay((0 + rand() % (5000 - 0)));
}

bool sendValues(float dado1) {
  char json[250];
  sprintf(json, "{ \"Pressão\": %02.02f }", dado1);

  Serial.println("\nTrying a transmission");
  int result = device.send(json);

  if (result == 1) {
    Serial.println("Sent!");
    device.showInfo();
    return true;
  } else {
    Serial.println("Error number " + String(dado1));
    return false;
  }
}

/* ____________________________ Deep Sleep _________________________________________ */

void begin_deepSleep(int time_to_sleep) {
  esp_sleep_enable_timer_wakeup(time_to_sleep * us_to_s_factor);
  Serial.println("Setup ESP32 to sleep for every " + String(time_to_sleep) + " Seconds");

  Serial.println("Entrando em Deep Sleep...");
  device.sleep();  // Desativar LoRa
  delay_millis(1000);
  Serial.flush();
  esp_deep_sleep_start();
}

void print_wakeup_reason() {
  esp_sleep_wakeup_cause_t wakeup_reason;

  wakeup_reason = esp_sleep_get_wakeup_cause();

  switch (wakeup_reason) {
    case ESP_SLEEP_WAKEUP_EXT0: Serial.println("Wakeup caused by external signal using RTC_IO"); break;
    case ESP_SLEEP_WAKEUP_EXT1: Serial.println("Wakeup caused by external signal using RTC_CNTL"); break;
    case ESP_SLEEP_WAKEUP_TIMER: Serial.println("Wakeup caused by timer"); break;
    case ESP_SLEEP_WAKEUP_TOUCHPAD: Serial.println("Wakeup caused by touchpad"); break;
    case ESP_SLEEP_WAKEUP_ULP: Serial.println("Wakeup caused by ULP program"); break;
    default: Serial.printf("Wakeup was not caused by deep sleep: %d\n", wakeup_reason); break;
  }
}

/* ____________________________ Watchdog Timer _____________________________________ */
void WDT_setup() {
  /* Algumas máquinas funcionam com esp_task_wdt_init(WDT_TIMEOUT, true) e esp_task_wdt_add*/
  /* outras funcionam com  esp_task_wdt_config_t, esp_task_wdt_init(&twdt_config) e esp_task_wdt_add*/

  // esp_task_wdt_config_t twdt_config = {
  //   .timeout_ms = WDT_TIMEOUT * 1000,
  //   .idle_core_mask = (1 << portNUM_PROCESSORS) - 1,  // Bitmask of all cores
  //   .trigger_panic = true,
  // };
  // esp_task_wdt_init(&twdt_config);

  esp_task_wdt_init(WDT_TIMEOUT, true);
  esp_task_wdt_add(NULL);

  // ESP_ERROR_CHECK(esp_task_wdt_reconfigure(&twdt_config));
}

/* ____________________________ Outras Funções _____________________________________ */
void delay_millis(int period) {
  unsigned long int time_now = millis();
  while (millis() < time_now + period) {
    //wait approx. [period] ms
  }
}

/* ____________________________ Armazenador de medidas _____________________________ */
void armazenador_cheio() {
  for (int i = 1; i < medidas_armazenadas; i++) {
    armazenador[i - 1] = armazenador[i];
  }
  indices_ocupados--;
}

void show_armazenador() {
  Serial.print("Armazenador:");
  for (int i = 0; i < medidas_armazenadas; i++) {
    Serial.print(" ");
    Serial.print(armazenador[i]);
  }
}

void armazenar(float dado) {
  armazenador[indices_ocupados] = dado;
  indices_ocupados++;
}

void enviar_dados_armazenados() {
  for (int i = 0; i < indices_ocupados; i++) {
    sendValues(armazenador[i]);
    armazenador[i] = 0;
    esp_task_wdt_reset();  // Resetar o Watchdog Timer periodicamente para evitar o reinício
  }
  indices_ocupados = 0;
}