/* Configuraçãp do LoRa */
const String GATEWAY_ID = "A0A3B321EF0C";
#define MISO_LORA 19      // azul
#define MOSI_LORA 23      // verde
#define SCK_LORA 18       // branco
#define SS_PIN_LORA 15    // amarelo
#define DIO0_PIN_LORA 5   // branco paralelo ao vermelho   
#define RESET_PIN_LORA 2  // laranja

/* Configuração Watchdog Timer */
#define WDT_TIMEOUT 300  // Definir tempo limite do Watchdog (em segundos)

/* Configurção armazenador de medidas */
const int medidas_armazenadas = 28;

/* Configuração de frequência de amostragem */
#define TIME_TO_SLEEP_NORMAL 30    // Tempo de deep sleep padrão em segundos
#define TIME_TO_SLEEP_ALTERADO 20  // tempo de deep sleep em caso de variação rápida
#define CICLOS_ALTERADO 3          // quantidade de medidas com tempo de deep sleep reduzido

/* Configuração de limites de pressão */
#define PRESSAO_MINIMA 10
#define PRESSAO_MAXIMA 150
#define VARIACAO_PRESSAO_MAX 30