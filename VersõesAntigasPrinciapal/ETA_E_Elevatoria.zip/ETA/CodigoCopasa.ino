#include <Wire.h>
#include <Adafruit_ADS1X15.h>
#include <PubSubClient.h>
#include "SSLClient.h"
#include "certificados.h"
#include "esp_task_wdt.h"
#include "esp_sleep.h"
#include <SPI.h>
#include "WiFi.h"
#include <esp_wifi.h>
#include "LoRaDeviceCSMACA.h"

const String GATEWAY_ID = "A0A3B321EF0C";

#define TINY_GSM_MODEM_SIM800
#define TINY_GSM_RX_BUFFER 1024
#include <TinyGsmClient.h>

#define SerialAT Serial1

#define ADS1115_ADDR1 0x48 // Endereço I2C do primeiro módulo ADS1115
#define ADS1115_ADDR2 0x49 // Endereço I2C do segundo módulo ADS1115

#define TRIGGER_PIN  17 // Pino Trig do Sensor Ultrassônico
#define ECHO_PIN 16     // Pino Echo do Sensor Ultrassônico

/*const int RX_SIM = 26;  // Pino RX do Módulo 3G
const int TX_SIM = 27;  // Pino TX do Módulo 3G*/

// Pins for LoRa antenna
#define MISO_LORA 19
#define MOSI_LORA 23
#define SCK_LORA 18
#define SS_PIN_LORA 15
#define DIO0_PIN_LORA 5
#define RESET_PIN_LORA 2

LoRaDevice device(GATEWAY_ID);

#define uS_TO_S_FACTOR 1000000
#define TIME_TO_SLEEP DEFAULT_SLEEP_TIME * uS_TO_S_FACTOR

#define VARIACAO_PH 0.5
#define VARIACAO_DISTANCIA 5.0
#define VARIACAO_NTU 100.0

#define SHORT_INTERVAL 150
#define LONG_INTERVAL 300

/*const char *APN = "zap.vivo.com.br"; // APN da operadora
const char *USER_MODEM = "vivo";     // Usuário da operadora
const char *PASS_MODEM = "vivo";     // Senha da operadora

const char *APN = "claro.com.br ";
const char *USER_MODEM = "claro";
const char *PASS_MODEM = "claro";*/

const char *MQTT_USER = "lite";      // Usuário para conexão MQTT
const char *MQTT_PASS = "lite123";   // Senha para conexão MQTT
#define ID_DEVICE "Vinicius"         // ID do dispositivo
#define SERVER "150.164.102.217"     // IP do servidor
#define PORT 8883                    // Porta reservada MQTT com TLS
#define TOPIC "ETA_Sensores"         // Tópico MQTT

#define WDT_TIMEOUT 60000  // Definir tempo limite do Watchdog

#define CONFIG_FREERTOS_NUMBER_OF_CORES 1 
esp_task_wdt_config_t twdt_config = {
        .timeout_ms = WDT_TIMEOUT,
        .idle_core_mask = (1 << CONFIG_FREERTOS_NUMBER_OF_CORES) - 1,    // Bitmask of all cores
        .trigger_panic = true,
    };

// Inicialização do módulo 3G
TinyGsm modemGSM(SerialAT);
TinyGsmClient gsmClient(modemGSM);
SSLClient secure(&gsmClient);
PubSubClient client(secure);

// Instâncias dos módulos ADS1115
Adafruit_ADS1115 ads1; // Primeiro módulo ADS
Adafruit_ADS1115 ads2; // Segundo módulo ADS

// Configurações de calibração do pH
#define UTILIZAR_PH_10 false // true para calibrar com pH 7 e pH 10, false para pH 7 e pH 4

const int numSamples = 5; // Número de amostras para o pH

// Valores de calibração
float calibPH7 = 2.0; // Tensão em solução de pH 7
float calibPH4 = 1.0; // Tensão em solução de pH 4
float calibPH10 = 3.0; // Tensão em solução de pH 10

RTC_DATA_ATTR int bootCount = 0;
RTC_DATA_ATTR int criticalEventCount = 0;
RTC_DATA_ATTR int prevCriticalEventCount = 0;

// Variáveis de Sensores
RTC_DATA_ATTR float distance;
RTC_DATA_ATTR float NTU;
RTC_DATA_ATTR float pH;
RTC_DATA_ATTR float prevDistance = -1;
RTC_DATA_ATTR float prevPH = -1;
RTC_DATA_ATTR float prevNTU = -1;
RTC_DATA_ATTR long intervalRead = LONG_INTERVAL;
float duration;
int result;

int criticalEventUltra = 0;
int criticalEventpH = 0;
int criticalEventNTU = 0;
int startTime;

float slope, intercept; // Coeficientes da equação linear
float sampleBuffer[numSamples]; // Buffer de amostras para pH

hw_timer_t *timer = NULL; // Controle do temporizador (interrupção por tempo)

int aux1, aux2, aux3, aux4;
/*void setupGSM() {
    Serial.printf("Setup GSM: ");
    SerialAT.begin(9600, SERIAL_8N1, RX_SIM, TX_SIM);
    Serial.println(modemGSM.getModemInfo());
    startTime = millis();
    if (!modemGSM.init()) {
        Serial.println("ERRO: Não inicializado");
        while (millis() - startTime < 2000)
        ESP.restart();
        return;
    }
    Serial.println("Modem OK");

    startTime = millis();
    if (!modemGSM.waitForNetwork()) {
        Serial.println("Falha de conexão à rede (Torre)");
        while (millis() - startTime < 10000)
        ESP.restart();
        return;
    }
    Serial.println("Modem Network OK");

    startTime = millis();
    if (!modemGSM.gprsConnect(APN, USER_MODEM, PASS_MODEM)) {
        Serial.println("Falha de Conexão GPRS");
        while (millis() - startTime < 10000)
        ESP.restart();
        return;
    }
    Serial.println("Conectado ao GSM!");
}

void connectToMQTT() {
    secure.setCACert(MQTT_CA);
    secure.setCertificate(MQTT_CE);
    secure.setPrivateKey(MQTT_KEY);
    client.setServer(SERVER, PORT);

    if (client.state() != 0) {
        Serial.print("Conectando ao servidor MQTT: ");
        if (client.connect(ID_DEVICE, MQTT_USER, MQTT_PASS)) {
            Serial.println("Conectado");
        } else {
            Serial.println("Não conectado (erro " + String(client.state()) + ")");
        }
    }
}

void reconnect() {
    while (!client.connected()) {
        Serial.print("\nConectando ao servidor MQTT: ");

        if (client.connect(ID_DEVICE, MQTT_USER, MQTT_PASS)) {
            Serial.println("Conectado");
        } else {
            Serial.println("Não conectado (erro " + String(client.state()) + ")");
        }
    }
    Serial.println("Reconectado");
}*/

void connectLoRa()
{
    WiFi.mode(WIFI_STA);
    WiFi.STA.begin();
    
    // Initialize SPI communication
    SPI.begin(SCK_LORA, MISO_LORA, MOSI_LORA, SS_PIN_LORA);

    // Set LoRa gateway pins
    device.setPins(SS_PIN_LORA, RESET_PIN_LORA, DIO0_PIN_LORA);

    // Begin LoRa device communication:
    if(!device.LoRaBegin(915E6)) Serial.println("\n[LoRa Device] Communication with LoRa radio failed");
    else Serial.println("\n[LoRa Device] Communication with LoRa radio successful");
    
    // Set private keys
    device.setDebug(true);

    // Sets Devices MAC
    device.setDeviceId(WiFi.macAddress());
    delay((0+rand()%(5000-0)));
}

bool sendValues(float dist, float pH, float NTU, int evDist, int evpH, int evNTU) {
    char json[250];
    sprintf(json, "{\"distancia\": %.02f, \"pH\": %.02f, \"NTU\": %.02f, \"EvDist\": %d, \"EvpH\": %d, \"EvNTU\": %d}", dist, pH, NTU, evDist, evpH, evNTU);
    result = device.send(json);
    return result;
}

void calibraPH() {
    if (calibPH7 == 0 && calibPH4 == 0 && calibPH10 == 0) {
        Serial.println("Erro - Valores de calibração não definidos!");
        while (1); // Bloqueia o programa
    }

    if (!UTILIZAR_PH_10 && calibPH4 == 0 && calibPH10 != 0 && calibPH7 != 0) {
        Serial.println("Erro - Defina UTILIZAR_PH_10 como true para usar calibração com pH 10.");
        while (1); // Bloqueia o programa
    }

    if (UTILIZAR_PH_10) {
        slope = (7.0 - 10.0) / (calibPH7 - calibPH10);
        intercept = 10.0 - slope * calibPH10;
    } else {
        slope = (4.0 - 7.0) / (calibPH4 - calibPH7);
        intercept = 7.0 - slope * calibPH7;
    }
}

void configuraADS() {
    if (!ads1.begin(ADS1115_ADDR1) || !ads2.begin(ADS1115_ADDR2)) {
        Serial.println("Falha ao inicializar o ADS.");
        if(!ads1.begin(ADS1115_ADDR1)){
          Serial.println("Falha ao inicializar o ADS 1.");
        }
        if(!ads2.begin(ADS1115_ADDR2)){
          Serial.println("Falha ao inicializar o ADS 2.");
        }
        while (1); // Bloqueia o programa
    }

    ads1.setGain(GAIN_TWOTHIRDS); // Configura ganho para o primeiro ADS1115
    ads2.setGain(GAIN_TWOTHIRDS); // Configura ganho para o segundo ADS1115
}

// Funções de Sensores
void sensorUltrassonico() {
        float velocidadeSOM = 331.45 / 20000;
        
        // Enviar o pulso de trigger
        digitalWrite(TRIGGER_PIN, LOW);
        delayMicroseconds(2);
        digitalWrite(TRIGGER_PIN, HIGH);
        delayMicroseconds(10);
        digitalWrite(TRIGGER_PIN, LOW);
        
        // Medir o tempo do pulso de eco
        duration = pulseIn(ECHO_PIN, HIGH); // Lê o tempo que o eco leva para voltar
        distance = duration * velocidadeSOM;
        
        if (prevDistance >= 0 && abs(distance - prevDistance) > VARIACAO_DISTANCIA) {
            Serial.println("Evento Crítico Detectado: Distância");
            criticalEventCount++;
            criticalEventUltra = 1;
        } else {
          criticalEventUltra = 0;
        }
        prevDistance = distance;
        
        Serial.print("Distância: ");
        Serial.println(distance);
        aux1 = 1;
}


void sensorPH() {
    // Lógica para medir pH
    float voltage = ads1.computeVolts(ads1.readADC_SingleEnded(0));
    pH = 7.0 + (voltage - 2.0); // Substituir por calibração real
    if (prevPH >= 0 && abs(pH - prevPH) > VARIACAO_PH) {
        Serial.println("Evento Crítico Detectado: pH");
        criticalEventCount++;
        criticalEventpH = 1;
    } else {
      criticalEventpH = 0;
    }
    prevPH = pH;
    Serial.print("pH: ");
    Serial.println(pH);
    aux2 = 1;
}

void sensorTurbidez() {
    // Lógica para medir turbidez
    float voltage = ads2.computeVolts(ads2.readADC_SingleEnded(0));
    NTU = -1120.4 * voltage * voltage + 5742.3 * voltage - 4353.8;
    if (prevNTU >= 0 && abs(NTU - prevNTU) > VARIACAO_NTU) {
        Serial.println("Evento Crítico Detectado: Turbidez");
        criticalEventCount++;
        criticalEventNTU = 1;
    } else {
      criticalEventNTU = 0;
    }
    prevNTU = NTU;
    Serial.print("NTU: ");
    Serial.println(NTU);
    aux3 = 1;
}

// Configuração e Loop Principal
void setup() {
    Serial.begin(115200);

    pinMode(TRIGGER_PIN, OUTPUT);  // Inicialização do Trigger do sensor Ultrssônico
    pinMode(ECHO_PIN, INPUT);      // Inicialização do Echo do sensor Ultrssônico

    Wire.begin();                    // Inicializa o barramento I2C
    esp_task_wdt_deinit();           
    esp_task_wdt_init(&twdt_config); // Inicializa o Watchdog
    esp_task_wdt_add(NULL); 
    calibraPH();                     // Calibra sensor de pH
    configuraADS();                  // Configura o ADS

    //setupGSM();                      // Inicialização do Módulo 3G
    //connectToMQTT();                 // Conecta ao MQTT
    connectLoRa();
    device.showInfo();

    esp_sleep_enable_timer_wakeup(intervalRead * uS_TO_S_FACTOR);
    Serial.println("Inicialização Completa");
    bootCount++;
    Serial.printf("Boot: %d\n", bootCount);
} 
void loop() {
    esp_task_wdt_reset();

    if(aux1 == 0){
      sensorUltrassonico();
    }
    
    if(aux2 == 0){
      aux1 = 0;
      sensorPH();
    }

    if(aux3 == 0){
      aux2 = 0;
      sensorTurbidez();
    }

    sendValues(distance, pH, NTU, criticalEventUltra, criticalEventpH, criticalEventNTU);
    if(result == 1){
      device.showInfo();
      aux3 = 0;
    } else {
      Serial.println("Error number " + String(result));
      aux3 = 0;
    }
    //reconnect();
    if(device.alertFromGateway())

    if (criticalEventCount == 0){
      intervalRead = LONG_INTERVAL;
    }
    
    if (criticalEventCount >= 1) {
        criticalEventCount--;
        intervalRead = SHORT_INTERVAL;
    }

    Serial.println("Entrando em Deep Sleep");
    esp_deep_sleep_start();
    device.sleep();
}