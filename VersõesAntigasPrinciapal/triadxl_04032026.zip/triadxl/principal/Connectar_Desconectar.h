#ifndef CONNECTAR_DESCONECTAR_H
#define CONNECTAR_DESCONECTAR_H

// --- Definições Globais ---
#define NUM_AMOSTRAS 512      // Total coletado (RAM)
#define TAMANHO_BACKUP 64     // Total salvo no RTC

#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h> // TLS
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <esp_task_wdt.h>
#include "Certificados_MQTT.h"

/* ============================================================
   CÓDIGO 4G (SEM TLS) - COMENTADO PARA USO FUTURO
   ============================================================
// #define TINY_GSM_MODEM_SIM7600
// #define TINY_GSM_RX_BUFFER 4096
// #define SerialAT Serial2
// extern int MODEM_PWRKEY;
// #include <TinyGsmClient.h>

// TinyGsm modem(SerialAT);
// TinyGsmClient modemClient(modem); 
// PubSubClient client(modemClient); // Direto no modemClient, sem SSL

// bool iniciarModem4G() { ... }
// void desconectarGPRS() { ... }
   ============================================================ */

// ============================================================
// TÓPICOS MQTT para 3 sensores, pressão e temperatura
// ============================================================
#define TOPIC_VIBRA_S1_REAL   "vibracao/sensor1/dados"
#define TOPIC_VIBRA_S2_REAL   "vibracao/sensor2/dados"
#define TOPIC_VIBRA_S3_REAL   "vibracao/sensor3/dados"
#define TOPIC_VIBRA_S1_BACKUP "vibracao/sensor1/backup"
#define TOPIC_VIBRA_S2_BACKUP "vibracao/sensor2/backup"
#define TOPIC_VIBRA_S3_BACKUP "vibracao/sensor3/backup"
#define TOPIC_PRESSAO_REAL    "pressao/dados"
#define TOPIC_PRESSAO_BACKUP  "pressao/backup"
#define TOPIC_TEMP_REAL       "temperatura/dados"
#define TOPIC_TEMP_BACKUP     "temperatura/backup"

// Configurações Rede WiFi
const char WIFI_SSID[] = "WIFI-LITE";
const char WIFI_PASS[] = "LITE@IOT";

// Configurações MQTT com TLS
#define MQTT_SERVER "150.164.102.217"
const int MQTT_PORT = 8883; 
const String CLIENT_ID = "LITE_DUAL_ACCEL";
const char *MQTT_USER = "lite";
const char *MQTT_PASS = "lite123";

// Buffers JSON
static StaticJsonDocument<512> jsonSmall;
static DynamicJsonDocument jsonLarge(4096);
static char mqttMsgBuffer[4096];

// Instâncias WiFi com TLS
WiFiClientSecure espClient;
PubSubClient client(espClient);

typedef struct { int16_t x, y, z; } AmostraAcelerometro;

extern AmostraAcelerometro backupSensor1[4][TAMANHO_BACKUP];
extern AmostraAcelerometro backupSensor2[4][TAMANHO_BACKUP];
extern AmostraAcelerometro backupSensor3[4][TAMANHO_BACKUP];
extern float backupPressao[4];
extern float backupTemperatura[4]; // Nova variável de backup

// --- Funções Auxiliares ---
inline void waitMs(uint32_t ms) { vTaskDelay(pdMS_TO_TICKS(ms)); }

bool conectarWiFi() {
    if (WiFi.status() == WL_CONNECTED) return true;
    
    Serial.printf("[WIFI] Conectando a %s...\n", WIFI_SSID);
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    
    unsigned long t0 = millis();
    while (WiFi.status() != WL_CONNECTED) {
        if (millis() - t0 > 15000) {
            Serial.println("\n[WIFI] Timeout de conexao!");
            return false;
        }
        waitMs(500);
        Serial.print(".");
    }
    Serial.println("\n[WIFI] Conectado com sucesso!");
    return true;
}

bool conectarRedeEbroker() {
    if (!conectarWiFi()) return false;

    // Aplica os certificados para a conexão TLS
    
    espClient.setCACert(MQTT_CA);
    espClient.setCertificate(MQTT_CE);
    espClient.setPrivateKey(MQTT_KEY); 

    client.setServer(MQTT_SERVER, MQTT_PORT);
    client.setBufferSize(sizeof(mqttMsgBuffer) + 256);
    client.setKeepAlive(60);

    unsigned long t0 = millis();
    while (!client.connected()) {
        if (millis() - t0 > 30000) return false;

        char idTemp[50];
        snprintf(idTemp, sizeof(idTemp), "%s_%04X", CLIENT_ID.c_str(), (uint16_t)esp_random());

        Serial.println("[MQTT] Tentando conectar ao broker via TLS...");
        if (client.connect(idTemp, MQTT_USER, MQTT_PASS)) {
            Serial.println("[MQTT] Conectado ao broker com sucesso!");
            return true;
        }
        
        Serial.printf("[MQTT] Falha, rc=%d. Tentando novamente em 2s...\n", client.state());
        waitMs(2000);
    }
    return true;
}

void desconectarRede() {
    if (client.connected()) { 
        client.disconnect(); 
        waitMs(200); 
    }
    WiFi.disconnect(true);
    WiFi.mode(WIFI_OFF);
    Serial.println("[REDE] Desconectado e WiFi desligado.");
}

// ============================================================
//   Funções de Envio MQTT
// ============================================================
bool enviarBackupVibracao(int sensorID, int indiceTurno, int indiceArrayRTC, AmostraAcelerometro* backupArray) {
    jsonLarge.clear();
    jsonLarge["tipo"] = "BACKUP_RAW";
    jsonLarge["sensor"] = sensorID;
    jsonLarge["turno"] = indiceTurno;

    JsonArray dataX = jsonLarge.createNestedArray("x");
    JsonArray dataY = jsonLarge.createNestedArray("y");
    JsonArray dataZ = jsonLarge.createNestedArray("z");

    for (int i = 0; i < TAMANHO_BACKUP; i++) {
        dataX.add(backupArray[i].x);
        dataY.add(backupArray[i].y);
        dataZ.add(backupArray[i].z);
    }

    size_t n = serializeJson(jsonLarge, mqttMsgBuffer, sizeof(mqttMsgBuffer));

    const char* topic;
    if (sensorID == 1) topic = TOPIC_VIBRA_S1_BACKUP;
    else if (sensorID == 2) topic = TOPIC_VIBRA_S2_BACKUP;
    else topic = TOPIC_VIBRA_S3_BACKUP;

    if (client.publish(topic, mqttMsgBuffer, n)) {
        client.loop();
        Serial.printf("[MQTT] SUCESSO: Backup S%d turno %d enviado.\n", sensorID, indiceTurno);
        return true;
    }
    return false;
}

bool enviarBackupPressao(int indiceTurno, int indiceArrayRTC) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "BACKUP_PRESSAO";
    jsonSmall["turno"] = indiceTurno;
    jsonSmall["val"] = backupPressao[indiceArrayRTC];

    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));

    if (client.publish(TOPIC_PRESSAO_BACKUP, mqttMsgBuffer, n)) {
        client.loop();
        Serial.printf("[MQTT] SUCESSO: Backup Pressao turno %d enviado.\n", indiceTurno);
        return true;
    }
    return false;
}

bool enviarBackupTemperatura(int indiceTurno, int indiceArrayRTC) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "BACKUP_TEMP";
    jsonSmall["turno"] = indiceTurno;
    jsonSmall["val"] = backupTemperatura[indiceArrayRTC];

    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));

    if (client.publish(TOPIC_TEMP_BACKUP, mqttMsgBuffer, n)) {
        client.loop();
        Serial.printf("[MQTT] SUCESSO: Backup Temperatura turno %d enviado.\n", indiceTurno);
        return true;
    }
    return false;
}

bool enviarVibracaoRealTimeChunked(int sensorID, AmostraAcelerometro* bufferRaw) {
    int totalPartes = NUM_AMOSTRAS / 256; 

    for (int parte = 0; parte < totalPartes; parte++) {
        jsonLarge.clear();
        jsonLarge["tipo"] = "REALTIME_FULL";
        jsonLarge["sensor"] = sensorID;
        jsonLarge["parte"] = parte + 1;
        jsonLarge["total"] = totalPartes;

        JsonArray dataX = jsonLarge.createNestedArray("x");
        JsonArray dataY = jsonLarge.createNestedArray("y");
        JsonArray dataZ = jsonLarge.createNestedArray("z");

        int inicio = parte * 256;
        int fim = inicio + 256;

        for (int i = inicio; i < fim; i++) {
            dataX.add(bufferRaw[i].x);
            dataY.add(bufferRaw[i].y);
            dataZ.add(bufferRaw[i].z);
        }

        size_t n = serializeJson(jsonLarge, mqttMsgBuffer, sizeof(mqttMsgBuffer));

        const char* topic;
        if (sensorID == 1) topic = TOPIC_VIBRA_S1_REAL;
        else if (sensorID == 2) topic = TOPIC_VIBRA_S2_REAL;
        else topic = TOPIC_VIBRA_S3_REAL;

        if (!client.publish(topic, mqttMsgBuffer, n)) return false;

        client.loop();
        Serial.printf("[MQTT] SUCESSO: Vibração S%d (Parte %d/%d) enviada.\n", sensorID, parte + 1, totalPartes);
        waitMs(150);
    }
    return true;
}

bool enviarPressaoRealTime(float medidaVolts) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "REALTIME";
    jsonSmall["val"] = medidaVolts;
    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));

    if (client.publish(TOPIC_PRESSAO_REAL, mqttMsgBuffer, n)) {
        client.loop();
        Serial.println("[MQTT] SUCESSO: Pressão enviada.");
        return true;
    }
    return false;
}

bool enviarTemperaturaRealTime(float temperatura) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "REALTIME";
    jsonSmall["val"] = temperatura;
    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));

    if (client.publish(TOPIC_TEMP_REAL, mqttMsgBuffer, n)) {
        client.loop();
        Serial.println("[MQTT] SUCESSO: Temperatura enviada.");
        return true;
    }
    return false;
}

void iniciarDeepSleep(unsigned long tempoInicioSetup) {
    #define CICLO_MINUTOS 0.5
    
    WiFi.mode(WIFI_OFF); 

    unsigned long tempoGasto = millis() - tempoInicioSetup;
    unsigned long cicloMs = CICLO_MINUTOS * 60 * 1000UL;
    
    // Calcula o tempo que falta para completar o ciclo, ou dorme 10s se o tempo excedeu
    unsigned long tempoDormirMs = (tempoGasto < cicloMs) ? (cicloMs - tempoGasto) : 10000UL;

    Serial.printf("\n[SLEEP] Ciclo concluído. Dormindo por %lu segundos...\n", tempoDormirMs / 1000);
    Serial.flush();
    esp_sleep_enable_timer_wakeup(tempoDormirMs * 1000ULL);
    esp_deep_sleep_start();
}
#endif