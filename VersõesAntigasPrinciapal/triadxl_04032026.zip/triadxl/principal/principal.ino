#include <Wire.h>
#include <type_traits>
#include <Adafruit_ADS1X15.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_ADXL345_U.h>
#include <max6675.h> // Biblioteca do Termopar
#include "esp_task_wdt.h"
#include "esp_sleep.h"
#include "Connectar_Desconectar.h"

#define WDT_TIMEOUT_MS 60000

/* ============================================================
   CÓDIGO 4G - COMENTADO PARA USO FUTURO
   ============================================================
// int MODEM_PWRKEY = 4;
   ============================================================ */

// ============================================================
// 3 ADXL345 em 2 barramentos I²C + ADS1115
// ============================================================
TwoWire I2C_2 = TwoWire(1); // Segundo barramento

Adafruit_ADXL345_Unified accel1(12345); // Barramento 1: 0x53 (SDO→GND)
Adafruit_ADXL345_Unified accel2(12346); // Barramento 1: 0x1D (SDO→3.3V)
Adafruit_ADXL345_Unified accel3(12347); // Barramento 2: 0x53 (SDO→GND)
Adafruit_ADS1115 ads;                   // Barramento 1: 0x48

// ============================================================
// Termopar MAX6675 (SPI)
// ============================================================
const int thermoSO = 19;
const int thermoCS = 5;
const int thermoSCK = 18;
MAX6675 thermocouple(thermoSCK, thermoCS, thermoSO);

// Semáforo
SemaphoreHandle_t dataReadySemaphore;

// ============================================================
// Buffers (512 amostras por sensor)
// ============================================================
AmostraAcelerometro bufferSensor1[NUM_AMOSTRAS];
AmostraAcelerometro bufferSensor2[NUM_AMOSTRAS];
AmostraAcelerometro bufferSensor3[NUM_AMOSTRAS];
unsigned long tempoInicioSetup;

// ============================================================
// Memória RTC (Backups para sensores)
// ============================================================
RTC_DATA_ATTR AmostraAcelerometro backupSensor1[4][TAMANHO_BACKUP];
RTC_DATA_ATTR AmostraAcelerometro backupSensor2[4][TAMANHO_BACKUP];
RTC_DATA_ATTR AmostraAcelerometro backupSensor3[4][TAMANHO_BACKUP];
RTC_DATA_ATTR float backupPressao[4] = {0.0, 0.0, 0.0, 0.0};
RTC_DATA_ATTR float backupTemperatura[4] = {0.0, 0.0, 0.0, 0.0};
RTC_DATA_ATTR int contBackup = 0;
RTC_DATA_ATTR int conteudo = 0;

// Controle de Turno
const int CICLOS_POR_TURNO = 36; // 6h = 36 * 10min
bool medidaImportante = false;
bool conectou = false;

// Medidas Atuais
float medidaPressaoAtual = 0.0;
float medidaTemperaturaAtual = 0.0;

void atualizaContador() {
    contBackup++;
    if (contBackup >= CICLOS_POR_TURNO) {
        medidaImportante = true;
        contBackup = 0;
    } else {
        medidaImportante = false;
    }
}

// -----------------------------
// Wrappers simples para selecionar barramento I2C
// -----------------------------
void selectBus(TwoWire *bus) {
    if (bus == &I2C_2) {
        Wire.begin(25, 26); // barramento 2
        Wire.setClock(10000);
    } else {
        Wire.begin(21, 22); // barramento 1 (padrão)
        Wire.setClock(4000);
    }
}

bool accelBegin(Adafruit_ADXL345_Unified &accel, uint8_t addr, TwoWire *bus = nullptr) {
    if (bus) {
        selectBus(bus);
        bool ok = accel.begin(addr);
        selectBus(nullptr); // restaura barramento 1
        return ok;
    }
    return accel.begin(addr);
}

void accelConfigure(Adafruit_ADXL345_Unified &accel, TwoWire *bus = nullptr) {
    if (bus) {
        selectBus(bus);
        accel.setDataRate(ADXL345_DATARATE_800_HZ);
        accel.setRange(ADXL345_RANGE_16_G);
        selectBus(nullptr);
    } else {
        accel.setDataRate(ADXL345_DATARATE_800_HZ);
        accel.setRange(ADXL345_RANGE_16_G);
    }
}

void accelGetEvent(Adafruit_ADXL345_Unified &accel, sensors_event_t *event, TwoWire *bus = nullptr) {
    if (bus) {
        selectBus(bus);
        accel.getEvent(event);
        selectBus(nullptr);
    } else {
        accel.getEvent(event);
    }
}

void collectSensorSamples(Adafruit_ADXL345_Unified &accel, AmostraAcelerometro *buffer, TwoWire *bus, const char* label) {
    Serial.printf("[SENSOR] Coletando %s...\n", label);
    unsigned long lastWdt = millis();
    for (int i = 0; i < NUM_AMOSTRAS; ++i) {
        sensors_event_t e;
        accelGetEvent(accel, &e, bus);
        buffer[i].x = (int16_t)(e.acceleration.x * 100);
        buffer[i].y = (int16_t)(e.acceleration.y * 100);
        buffer[i].z = (int16_t)(e.acceleration.z * 100);
        if (millis() - lastWdt > 2000) {
            esp_task_wdt_reset();
            lastWdt = millis();
        }
        vTaskDelay(pdMS_TO_TICKS(1));
    }
}

void enviarBackupsSeExistirem() {
    if (conteudo == 0) return;
    Serial.println("[BACKUP] Enviando pendentes...");

    bool tudoOk = true;
    for (int i = 0; i < conteudo; ++i) {
        if (!enviarBackupVibracao(1, i + 1, i, backupSensor1[i])) { tudoOk = false; break; }
        waitMs(200);
        if (!enviarBackupVibracao(2, i + 1, i, backupSensor2[i])) { tudoOk = false; break; }
        waitMs(200);
        if (!enviarBackupVibracao(3, i + 1, i, backupSensor3[i])) { tudoOk = false; break; }
        waitMs(200);
        if (!enviarBackupPressao(i + 1, i)) { tudoOk = false; break; }
        waitMs(200);
        if (!enviarBackupTemperatura(i + 1, i)) { tudoOk = false; break; }
        waitMs(200);
    }

    if (tudoOk) {
        Serial.println("[BACKUP] Limpando RTC.");
        conteudo = 0;
    }
}

void salvarBackupSeNecessario(bool sucessoEnvio) {
    if (!medidaImportante) return;
    if (sucessoEnvio) return;

    Serial.println("[RTC] Falha crítica. Salvando para o próximo ciclo...");
    if (conteudo >= 4) {
        Serial.println("[RTC] Vetor cheio. Resetando dia...");
        conteudo = 0;
    }

    for (int i = 0; i < TAMANHO_BACKUP; i++) {
        backupSensor1[conteudo][i] = bufferSensor1[i];
        backupSensor2[conteudo][i] = bufferSensor2[i];
        backupSensor3[conteudo][i] = bufferSensor3[i];
    }

    backupPressao[conteudo] = medidaPressaoAtual;
    backupTemperatura[conteudo] = medidaTemperaturaAtual;
    conteudo++;
    Serial.printf("[RTC] Salvo Slot %d (3 vib, 1 pres, 1 temp).\n", conteudo);
}

// ============================================================
// TASK SENSORS
// ============================================================}
void taskSensors(void *pv) {
    esp_task_wdt_add(NULL);
    
    // 1. Coleta Pressão (média de 5 leituras)
    float somaVolts = 0;
    for(int i=0; i<5; i++) {
        int16_t adc = ads.readADC_SingleEnded(0);
        somaVolts += ads.computeVolts(adc);
        vTaskDelay(pdMS_TO_TICKS(10));
    }
    medidaPressaoAtual = (somaVolts / 5.0) - 0.0024;

    // 2. Coleta Vibração - SENSOR 1 (Barramento 1 - 0x53)
    collectSensorSamples(accel1, bufferSensor1, nullptr, "ADXL #1 (0x53)");
    
    // 3. Coleta Vibração - SENSOR 2 (Barramento 1 - 0x1D)
    collectSensorSamples(accel2, bufferSensor2, nullptr, "ADXL #2 (0x1D)");
    
    // 4. Coleta Vibração - SENSOR 3 (Barramento 2 - 0x53)
    collectSensorSamples(accel3, bufferSensor3, &I2C_2, "ADXL #3 (Barramento 2)");

    // 5. Coleta Temperatura (MAX6675) - Movido para o final!
    // O hardware teve >1.5s para estabilizar enquanto as vibrações eram lidas.
    medidaTemperaturaAtual = thermocouple.readCelsius();
    if (isnan(medidaTemperaturaAtual)) {
        Serial.println("[ERRO] Falha na leitura do termopar MAX6675!");
        medidaTemperaturaAtual = -999.0;
    }
    
    // Libera a task de comunicação
    if (dataReadySemaphore != NULL) {
        xSemaphoreGive(dataReadySemaphore);
    } else {
        Serial.println("[WARN] dataReadySemaphore NULL, skipping give");
    }
    
    esp_task_wdt_delete(NULL);
    vTaskDelete(NULL);
}
// ============================================================
// TASK COMMUNICATION 
// ============================================================
void taskCommunication(void *pv) {
    esp_task_wdt_add(NULL);
    
    if (dataReadySemaphore != NULL && xSemaphoreTake(dataReadySemaphore, pdMS_TO_TICKS(WDT_TIMEOUT_MS)) == pdTRUE) {

        atualizaContador();
        Serial.printf("[DADOS] Pressao: %.3f V | Temp: %.2f C\n", medidaPressaoAtual, medidaTemperaturaAtual);

        bool sucessoEnvio = false;

        conectou = conectarRedeEbroker();
        
        if (conectou) {
            enviarBackupsSeExistirem();
            
            bool s1OK = enviarVibracaoRealTimeChunked(1, bufferSensor1);
            waitMs(200);
            bool s2OK = enviarVibracaoRealTimeChunked(2, bufferSensor2);
            waitMs(200);
            bool s3OK = enviarVibracaoRealTimeChunked(3, bufferSensor3);
            waitMs(200);
            bool pOK  = enviarPressaoRealTime(medidaPressaoAtual);
            waitMs(200);
            bool tOK  = enviarTemperaturaRealTime(medidaTemperaturaAtual);
            
            sucessoEnvio = (s1OK && s2OK && s3OK && pOK && tOK);

            waitMs(500);
            desconectarRede();
        } else {
            Serial.println("[ERRO] Nao foi possivel conectar a rede ou broker.");
        }
        
        salvarBackupSeNecessario(sucessoEnvio);
        
        // Finaliza o fluxo e coloca o ESP em Deep Sleep
        iniciarDeepSleep(tempoInicioSetup);

    } else {
        Serial.println("[ERRO] Timeout no Semaforo. Forcando sleep.");
        esp_sleep_enable_timer_wakeup(10ULL * 1000000ULL);
        esp_deep_sleep_start();
    }
    
    esp_task_wdt_delete(NULL);
    vTaskDelete(NULL);
}

// ============================================================
// SETUP
// ============================================================
void setup() {
    tempoInicioSetup = millis();
    Serial.begin(115200);

    // Inicializa barramentos I²C
    Wire.begin(21, 22);      // Barramento 1: SDA=21, SCL=22
    Wire.setClock(400000);
    
    I2C_2.begin(25, 26);     // Barramento 2: SDA=25, SCL=26
    I2C_2.setClock(400000);

    /* ============================================================
       CÓDIGO 4G - COMENTADO PARA USO FUTURO
       ============================================================
    // pinMode(MODEM_PWRKEY, OUTPUT);
    // digitalWrite(MODEM_PWRKEY, LOW);
       ============================================================ */
    vTaskDelay(pdMS_TO_TICKS(250));
    bool sensorsOK = true;
    
    if (!accelBegin(accel1, 0x53, nullptr)) {
        Serial.println("[ERRO] ADXL #1 (0x53) falhou!");
        sensorsOK = false;
    } else {
        accelConfigure(accel1, nullptr);
        Serial.println("[OK] ADXL #1 iniciado");
    }

    if (!accelBegin(accel2, 0x1D, nullptr)) {
        Serial.println("[ERRO] ADXL #2 (0x1D) falhou!");
        sensorsOK = false;
    } else {
        accelConfigure(accel2, nullptr);
        Serial.println("[OK] ADXL #2 iniciado");
    }

    if (!accelBegin(accel3, 0x53, &I2C_2)) {
        Serial.println("[ERRO] ADXL #3 (Barramento 2) falhou!");
        sensorsOK = false;
    } else {
        accelConfigure(accel3, &I2C_2);
        Serial.println("[OK] ADXL #3 (Barramento 2) iniciado");
    }

    if (!ads.begin()) {
        Serial.println("[ERRO] ADS1115 falhou!");
        sensorsOK = false;
    } else { 
        ads.setGain(GAIN_ONE);
        Serial.println("[OK] ADS1115 iniciado");
    }

    if(!sensorsOK) {
        Serial.println("[ERRO] Sensores I2C falharam. Entrando em sleep...");
        esp_sleep_enable_timer_wakeup(10ULL * 1000000ULL);
        esp_deep_sleep_start();
    }

    // Configura Watchdog
    esp_task_wdt_deinit();
    esp_task_wdt_config_t cfg = { .timeout_ms = WDT_TIMEOUT_MS, .trigger_panic = true };
    esp_task_wdt_init(&cfg);

    dataReadySemaphore = xSemaphoreCreateBinary();
    
    xTaskCreatePinnedToCore(taskCommunication, "TaskComms", 10000, NULL, 1, NULL, 0);
    xTaskCreatePinnedToCore(taskSensors, "TaskSensors", 8192, NULL, 2, NULL, 1);
    
    Serial.println("[SETUP] Sistema iniciado: 3x ADXL345, ADS1115 e MAX6675!");
}

void loop() { 
    vTaskDelay(portMAX_DELAY); 
}