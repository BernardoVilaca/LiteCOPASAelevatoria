// ========================================================================================================
// --- Mapeamento de Hardware ---
// ========================================================================================================
#define MOS      23 
#define PWM_PIN  33
// Endereços I2C dos sensores INA219
Adafruit_INA219 ina219_1(0x41); // INA de saída do conversor
Adafruit_INA219 ina219_2(0x44); // INA de entrada/bateria
// ========================================================================================================
//____________________________________Configurações Deep sleep_____________________________________________
#define SEGUNDOS_PARA_MICROSEGUNDOS 1000000ULL  /* Fator de conversão */
#define TEMPO_DE_SONO  30                       /* Tempo que ele vai dormir (em segundos) */

void iniciarDeepSleep() {
  // 1. Configura o despertar por timer
  esp_sleep_enable_timer_wakeup(TEMPO_DE_SONO * SEGUNDOS_PARA_MICROSEGUNDOS);
  
  Serial.println("Configurando o ESP32 para dormir por " + String(TEMPO_DE_SONO) + " segundos.");
  Serial.println("Indo dormir agora...");
  Serial.flush(); // Garante que a mensagem saia no serial antes de desligar

  // 2. Entra no modo Deep Sleep
  esp_deep_sleep_start();
}
// ========================================================================================================
// --- Parâmetros de PWM (LEDC ESP32) ---
// ========================================================================================================
const int PWM_CHANNEL    = 0;
const int PWM_RESOLUTION = 10; 
const int PWM_FREQ       = 50000; 
int Bit_Carga            = 1023; // Inicia em 1023 (tensão mínima no hardware atual)

// ========================================================================================================
// --- Variáveis de Controle e Estado ---
// ========================================================================================================   
int delei       = 0;
int aumenta = 0, diminui = 0, aux = 0;
int checkpoint  = 0;
byte binByte    = 0;
RTC_DATA_ATTR int controlador = 0, fonte = 0, carregou = 0, caiu = 0; 
RTC_DATA_ATTR double coulombs = 0.0;
RTC_DATA_ATTR float SoC = 0.0;
RTC_DATA_ATTR bool erro_ina1 = false;
RTC_DATA_ATTR bool erro_ina2 = false;
// ========================================================================================================
// --- Parâmetros de Carga e Segurança (float) ---
// ========================================================================================================
float Tensao_Alimentar = 14.2;
float Load_Corrente    = 750.0;
float tolerancia_UP    = 100.0;
float tolerancia_DOWN  = 50.0;
float safeLimit        = Load_Corrente + tolerancia_UP; // Load_Corrente + tolerancia_UP
float setpoint_inf     = 100.0;

// Shunts e Leituras Reaisf
float R_Shunt1 = 0.122, R_Shunt2 = 0.129;
float realCurrent1 = 0;
float realCurrent2 = 0;
float loadvoltage1 = 0;
float loadvoltage2 = 0;


// ========================================================================================================
// --- Gestão de Energia (Coulomb Counting) ---
// ========================================================================================================
float capNAmp        = 10;      // Valor base para cálculo
float capNAmph       = 1500.0;  // mAh
float capAtual       = 0;
float Coulomb_Bat    = 10.0 * 3600; // capNAmp * 3600 (Inicializado com literal para segurança)


// ========================================================================================================
// --- Temporização e Intervalos (unsigned long) ---
// ========================================================================================================
unsigned long tempoAtual      = 0;
unsigned long tempoAnterior   = 0;
unsigned long tempoAnterior2  = 0; 
unsigned long t_cmd           = 0; 
unsigned long t_Trigger       = 0; 
unsigned long lastMillis      = 0;
unsigned long now             = 0; 
unsigned long Timer           = 0;
unsigned long timer_inicio_carga = 0;
unsigned long dormir = 0;

// Intervalos
unsigned long intervalo         = 1200;
unsigned long intervalo2        = 500;  
unsigned long intervalo_Cmd     = 5000;
unsigned long intervalo_Trigger = 10000;
unsigned long Inter_Timer       = 5000;  
unsigned long Sleep_Timer       = 70000;  
const unsigned long TEMPO_CARENCIA = 5000;
//Biblioteca de funções do SIFE
//=========================================================================================================
//--------------------Funções----------------------------------//
void init_INA219(){
  if (! ina219_1.begin()) {
    Serial.println("Falha no INA219 1 (Bateria)");
    erro_ina1 = true;
  } else {
    Serial.println("INA 219 1 encontrado");
    erro_ina1 = false;
    ina219_1.setCalibration_32V_1A();
  }
  
  if (! ina219_2.begin()) {
    Serial.println("Falha no INA219 2 (Fonte)");
    erro_ina2 = true;
  } else {
    Serial.println("INA 219 2 encontrado");
    erro_ina2 = false;
    ina219_2.setCalibration_32V_1A();
  } 
}

// Função para calcular o SoC de uma bateria LiFePO4 de 12V (4 células)
int calcularSoC_LiFePO4(float tensaoBateria) {
    int soc = 0;

    // Acima de 13.6V está plenamente carregada (ou em processo de carga final)
    if (tensaoBateria >= 13.6) {
        soc = 100;
    } 
    // Curva plana superior (90% a 100%)
    else if (tensaoBateria >= 13.3) {
        soc = 90 + ((tensaoBateria - 13.3) * (10.0 / 0.3));
    } 
    // Queda leve (70% a 90%)
    else if (tensaoBateria >= 13.2) {
        soc = 70 + ((tensaoBateria - 13.2) * (20.0 / 0.1));
    } 
    // O meio da curva (40% a 70%)
    else if (tensaoBateria >= 13.1) {
        soc = 40 + ((tensaoBateria - 13.1) * (30.0 / 0.1));
    } 
    // Início da queda rápida (10% a 40%)
    else if (tensaoBateria >= 12.8) {
        soc = 10 + ((tensaoBateria - 12.8) * (30.0 / 0.3));
    } 
    // Fim da linha (0% a 10%) - Cuidado para o BMS não cortar a energia!
    else if (tensaoBateria >= 12.0) {
        soc = 0 + ((tensaoBateria - 12.0) * (10.0 / 0.8));
    } 
    // Abaixo de 12.0V consideramos vazia por segurança
    else {
        soc = 0;
    }

    // Trava os limites por precaução contra flutuações do sensor analógico
    if (soc > 100) soc = 100;
    if (soc < 0) soc = 0;

    return soc;
}

//Função de arredontamento de float
float Arredonda(float v) {
  // Inteiro de déciMOS (ex.: 13.66 → 136)
  int dezena = int(v * 10.0f);
  // Dígito das centésimas (ex.: 13.66 → 1366 % 10 → 6)
  int centesima = (int)(v * 100.0f) % 10;
  
  if (centesima == 9) {
    // 13.9 → 139 → +1 → 140 → 14.0
    dezena += 1;
  }
  else if (centesima == 1) {
    // 13.1 → 131 → −1 → 130 → 13.0
    dezena -= 1;
  }
// Retorna v truncado para uma casa decimal,
// mas arredonda para cima se o centésimo for 9,
// e arredonda para baixo se o centésimo for 1. 
  return dezena / 10.0f;
}
//Função para controle do MOSFET na placa do SIFE e para controle do distribuidor de energia
void Controle(int valor){
  if(valor == 1){
    digitalWrite(MOS , HIGH); //Ativa a carga da bateria                   //    |
  }else if(valor == 0){  
    digitalWrite(MOS , LOW); //Desativa a carga da bateria        //    | 
  }
}
//Função que le a tensão de saída do conversor dcdc através do ampop(Usar leitura via ads1115 para precisão adequada)
//float TensaoAmpop(float Vout_SEPIC){
//  return Vout_SEPIC = (analogRead(VO)/4095.0)*3.3;
//}
//Função que faz o monitoramento da potência de entrada e de carga da bateria
void Monitora(){
  float shuntvoltage1 = 0, shuntvoltage2 = 0;
  float busvoltage1 = 0, busvoltage2 = 0; 
  float power_mW1 = 0, power_mW2 = 0;
  float Rshunt = 0.1, perdas = 0; 
  tempoAtual = millis();
  if (tempoAtual - tempoAnterior2 >= intervalo2) {
    tempoAnterior2 = tempoAtual;         // Atualiza o tempo da última execução
    //Pega osa valores do INA219 1(mede a carga)
    shuntvoltage1 = ina219_1.getShuntVoltage_mV();
    busvoltage1 = ina219_1.getBusVoltage_V();
    realCurrent1 = shuntvoltage1/ R_Shunt1;
    perdas = ((realCurrent1/1000)*(Rshunt));
    loadvoltage1 = busvoltage1 + (shuntvoltage1 / 1000) - perdas; //Calibra a tensão lida sobre a carga contando com as perdas
    power_mW1 = realCurrent1 * loadvoltage1;
  //Pega os valores no INA219 2(mede a entrada do conversor)
    shuntvoltage2 = ina219_2.getShuntVoltage_mV();
    busvoltage2 = ina219_2.getBusVoltage_V(); 
    realCurrent2 = shuntvoltage2/ R_Shunt2;
    loadvoltage2 = busvoltage2 + (shuntvoltage2 / 1000);
    power_mW2 = realCurrent2 * loadvoltage2;
    if(realCurrent2 < 10.0 && loadvoltage2 < 1.0){ 
      fonte = 0;
    }else{
      fonte = 1;
    }  
      Serial.print("Queda no Shunt 1 :");
      Serial.print(shuntvoltage2); //MOStra as perdas
      Serial.println("mV");
      Serial.print("Tensao da FONTE:  "); Serial.print(loadvoltage2); Serial.println(" V");
      Serial.print("Corrente da FONTE:       "); Serial.print(realCurrent2); Serial.println(" mA");
      Serial.print("Potencia da FONTE:         "); Serial.print(power_mW2); Serial.println(" mW");
      Serial.println("");

      Serial.print("Queda no Shunt  2:");
      Serial.print(shuntvoltage1); //MOStra as perdas
      Serial.println("mV");
      Serial.print("Tensao na BATERIA:  "); Serial.print(loadvoltage1); Serial.println(" V");
      Serial.print("Corrente na BATERIA:       "); Serial.print(realCurrent1); Serial.println(" mA"); 
      Serial.print("Potencia na BATERIA:         "); Serial.print(power_mW1); Serial.println(" mW");
      Serial.println(""); 
      loadvoltage1 = Arredonda(loadvoltage1);  
  }
}
//Função que atua no controle da tensão de saída do conversor DC/DC, de forma similar a um potenciometro digital
void Pot_dig(){ 
  tempoAtual = millis();
    if (tempoAtual - tempoAnterior >= intervalo && Bit_Carga <= 1023 && checkpoint != 1) {  //Controla a tensão de carga 
      tempoAnterior = tempoAtual;    
      //Seleciona se aumenta ou diminui a tensão do conversor DC/DC
      if(realCurrent1 < Load_Corrente && realCurrent1 < safeLimit && Bit_Carga > 0){ 
        Bit_Carga-=10;   
        intervalo2 = 500; 
      }else if(realCurrent1 > safeLimit){
        Bit_Carga+=10;
        intervalo2 = 500;    
      }else{
        checkpoint = 1;
        intervalo2 = 5000;
      }  
      Serial.print("Bit:");
      Serial.println(Bit_Carga);
    }
  delay(10);
}   
//Função que faz a contagem dos coulombs que entram e saem da bateria
void ContaCoulomb() {
  unsigned long now = millis();
  unsigned long elapsed_ms = now - lastMillis;
  lastMillis = now;

  // Proteção contra falhas de tempo
  if (elapsed_ms > 2000 || elapsed_ms == 0) return;

  float shuntV = ina219_1.getShuntVoltage_mV();
  float Corrente_mA = shuntV / R_Shunt1; 

  if (coulombs == 0.0 && loadvoltage1 > 9.0) {
      Serial.println("[SIFE] Inicializando SoC baseado na tensão atual...");
      if (loadvoltage1 >= 13.0) coulombs = 5400.0;       // ~100%
      else if (loadvoltage1 >= 12.5) coulombs = 4050.0;  // ~75%
      else if (loadvoltage1 >= 12.0) coulombs = 2700.0;  // ~50%
      else if (loadvoltage1 >= 11.5) coulombs = 1350.0;  // ~25%
      else coulombs = 500.0;                             // Bateria fraca
  }
  
  double current_A = (double)Corrente_mA / 1000.0;
  double dt_s = (double)elapsed_ms / 1000.0;
  double deltaCoulomb = abs(current_A * dt_s);

  // Lógica de carga e descarga usando if/else
  if (fonte == 0) {
    coulombs -= deltaCoulomb;
  } else {
    coulombs += deltaCoulomb;
  }

  // Travas de segurança (Clamping)
  if (coulombs < 0)    coulombs = 0;
  if (coulombs > 5400) coulombs = 5400;

  // Cálculos de SoC e mAh
  SoC = (coulombs / 5400.0) * 100.0;
  double mAh_restante = (coulombs / 3600.0) * 1000.0;

  // Bloco de exibição Serial
  if (millis() - Timer >= Inter_Timer) {
    Timer = millis();

    Serial.print("Modo: ");
    if (fonte == 0) {
      Serial.print("DESCARGA");
    } else {
      Serial.print("CARGA");
    }
  
    Serial.print(" | Corrente: "); 
    Serial.print(Corrente_mA); 
    Serial.print("mA");
    
    Serial.print(" | Restante: "); 
    Serial.print(mAh_restante, 2); 
    Serial.print("mAh");
    
    Serial.print(" | Bateria: ");  
    Serial.print(SoC, 2); 
    Serial.println("%");
    
  }
}
//Função que implementa uma máquina de estados, comutando entre 3 modos: Carga da bateria, modo fonte DC e modo backup(Energia caiu)
void comandos() {
  // Máquina de Estados
  switch (controlador) {
    case 0: // DESLIGADO
      Controle(0);
      break;

    case 1: // FONTE DIRETA (BATERIA CHEIA) 
      Controle(0); 
      Bit_Carga = 0; 
      Pot_dig();
      intervalo2 = 5000;
      Monitora();
      break;

    case 2: // CARREGANDO (CC/CV)
      if(delei == 1){
        delay(3000);  //Esse delay é fundamental para evitar pico de corrente perigoso no transitório da fonte voltando 
      }
      delei = 0;
      if(aux == 0){
        Bit_Carga = 1020;
        checkpoint = 0;
        aux = 1;
      } 
      Controle(1);
      Pot_dig();
      Monitora();
      if(loadvoltage1 > 14.6 && Bit_Carga < 800){ 
        Controle(0);  
        Serial.println("Perigo: Excesso de tensão, protegendo bateria!");                
        Serial.println(">>> Bateria 100%. Mudando para modo Fonte.");
        coulombs = 5400;      // RESET: Balde cheio (1500mAh)
        carregou = 1;
        controlador = 1;
        aux = 0;
        checkpoint = 0;
        SoC = 100.0;
        Serial.println(">>> Contador resetado para 100% (Bateria Cheia)");
      }

      // Só verifica se acabou a carga se já passou o TEMPO DE CARENCIA (5s)
      if (millis() - timer_inicio_carga > TEMPO_CARENCIA) { 
        // Verifica se a corrente caiu (bateria cheia) 
        if (realCurrent1 <= setpoint_inf && realCurrent1 > 0.0 && fonte == 1 && checkpoint == 1) {
          Serial.println(">>> Bateria 100%. Mudando para modo Fonte.");
          coulombs = 5400;      // RESET: Balde cheio (1500mAh)
          carregou = 1;
          controlador = 1;
          aux = 0;
          checkpoint = 0;
          SoC = 100.0;
          Serial.println(">>> Contador resetado para 100% (Bateria Cheia)");
        }
      }
      break;

    case 3: // MODO BATERIA (SEM REDE) 
       Controle(0);  
       intervalo2 = 5000;
       Bit_Carga = 0;
       Monitora(); // Importante: Monitora continua rodando para detectar se a fonte voltou   Sleep_Timer,sleep
       if (millis() - dormir > Sleep_Timer) { 
        dormir = millis();
        iniciarDeepSleep();
       }
       break;
  }
}
//Função que usa de todas as anteriores para fazer o gerenciamento de carga do sistema. Essa função deve estar no void loop() !
void Gerenciamento_Carga(){
  // Primeiro executamos a máquina de estados para atualizar leituras 
  comandos();
  ledcWriteChannel(PWM_CHANNEL, Bit_Carga);

  // --- LÓGICA DE TRANSIÇÃO ---
  
  // 1. A FONTE CAIU
  if (fonte == 0) {
      if (controlador != 3) { 
        Serial.println("ALERTA: Fonte OFF. Usando Bateria!");  
        caiu = 1;         
        carregou = 0;     
        controlador = 3;  
        lastMillis = millis(); // Reseta para o cálculo de dt começar limpo
      }
  }
  // 2. A FONTE VOLTOU (Reação ao evento de retorno)
  else if (fonte == 1 && caiu == 1) {
    Serial.println(">>> Fonte VOLTOU. Iniciando recarga...");
    delei = 1;
    aux = 0;
    checkpoint = 0;
    caiu = 0;                // Limpa a flag de queda
    carregou = 0;            // Garante que o sistema saiba que precisa carregar
    timer_inicio_carga = millis(); 
    controlador = 2;         // Força o início da carga
  }
  // 3. MANUTENÇÃO DO ESTADO DE CARGA
  else if (fonte == 1 && carregou == 0 && controlador != 2) { 
    Serial.println("-----------Iniciando carga!-----------");
    timer_inicio_carga = millis(); // Reinicia timer para segurança
    controlador = 2;
    Bit_Carga = 1020;
  }

  // --- CRÍTICO ---
  // Roda sempre no final do ciclo para garantir que o SoC nunca fique em 0%
  // independente do modo (Carga, Descarga ou Standby)
  ContaCoulomb(); 
}
