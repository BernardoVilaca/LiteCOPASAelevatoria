#ifndef CONNECTAR_DESCONECTAR_H
#define CONNECTAR_DESCONECTAR_H

#define TINY_GSM_MODEM_A7670
#define NUM_AMOSTRAS 512      
#define TAMANHO_BACKUP 64     

#include <Arduino.h>
#include <TinyGsmClient.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <esp_task_wdt.h>

// --- PINOS DO MODEM (A7670) ---
#define MODEM_TX      17
#define MODEM_RX      16
#define MODEM_PWKEY   4
#define SerialAT      Serial1

// --- CONFIGURAÇÕES DE REDE ---
const char apn[]      = "zap.vivo.com.br";
const char gprsUser[] = "vivo";
const char gprsPass[] = "vivo";

// --- BROKER PÚBLICO (HIVE MQ) ---
#define MQTT_SERVER "broker.hivemq.com" 
const int MQTT_PORT = 1883; 
const char *MQTT_USER = ""; 
const char *MQTT_PASS = ""; 

// Tópicos 
#define TOPIC_VIBRA_S1_REAL   "sife_felipe/vibracao/sensor1/dados"
#define TOPIC_VIBRA_S2_REAL   "sife_felipe/vibracao/sensor2/dados"
#define TOPIC_VIBRA_S3_REAL   "sife_felipe/vibracao/sensor3/dados"
#define TOPIC_VIBRA_S1_BACKUP "sife_felipe/vibracao/sensor1/backup"
#define TOPIC_VIBRA_S2_BACKUP "sife_felipe/vibracao/sensor2/backup"
#define TOPIC_VIBRA_S3_BACKUP "sife_felipe/vibracao/sensor3/backup"
#define TOPIC_PRESSAO_REAL    "sife_felipe/pressao/dados"
#define TOPIC_PRESSAO_BACKUP  "sife_felipe/pressao/backup"
#define TOPIC_TEMP_REAL       "sife_felipe/temperatura/dados"
#define TOPIC_TEMP_BACKUP     "sife_felipe/temperatura/backup"

// Instâncias
static TinyGsm modem(SerialAT);
static TinyGsmClient gsmClient(modem);
static PubSubClient client(gsmClient);

// Buffers
static char mqttMsgBuffer[4096];
static StaticJsonDocument<512> jsonSmall;
static DynamicJsonDocument jsonLarge(4096);

typedef struct { int16_t x, y, z; } AmostraAcelerometro;

extern AmostraAcelerometro backupSensor1[4][TAMANHO_BACKUP];
extern AmostraAcelerometro backupSensor2[4][TAMANHO_BACKUP];
extern AmostraAcelerometro backupSensor3[4][TAMANHO_BACKUP];
extern float backupPressao[4];
extern float backupTemperatura[4];

inline void waitMs(uint32_t ms) { vTaskDelay(pdMS_TO_TICKS(ms)); }

bool conectarRedeEbroker() {
    Serial.println("\n[4G] Iniciando Sequencia Resiliente de Power ON...");
    pinMode(MODEM_PWKEY, OUTPUT);

    // Tenta inicializar. Se falhar, dá um pulso longo para "despertar" ou resetar
    if (!modem.init()) {
        Serial.println("[4G] Modem travado. Forcando reset de hardware...");
        digitalWrite(MODEM_PWKEY, HIGH);
        delay(3000); 
        digitalWrite(MODEM_PWKEY, LOW);
        delay(5000);
    }

    int timeout = 0;
    while (!modem.init() && timeout < 20) {
        Serial.print(".");
        esp_task_wdt_reset();
        digitalWrite(MODEM_PWKEY, HIGH);
        delay(1500);
        digitalWrite(MODEM_PWKEY, LOW);
        delay(2000);
        timeout++;
    }
    
    if (timeout >= 20) {
        Serial.println(" FALHOU!");
        return false;
    }
    Serial.println(" OK!");

    // Limpeza de estado
    /*
    modem.sendAT("+CGATT=0"); 
    modem.waitResponse(5000);
    
    modem.sendAT("+CGDCONT=1,\"IP\",\"" + String(apn) + "\"");*/
    modem.waitResponse();

    int csq = modem.getSignalQuality();
    Serial.print("[4G] Qualidade do Sinal (CSQ): ");
    Serial.println(csq);

    Serial.print("[4G] Registrando na rede Vivo...");
    if (!modem.waitForNetwork(60000L)) {
        Serial.println(" FALHOU!");
        return false;
    }
    Serial.println(" OK!");

    modem.sendAT("+CGATT=1");
    modem.waitResponse(10000);

    Serial.print("[4G] Abrindo GPRS (" + String(apn) + ")...");
    esp_task_wdt_reset(); 
    
    if (!modem.gprsConnect(apn, gprsUser, gprsPass)) {
        Serial.println(" FALHOU!");
        Serial.println("[4G] Reiniciando stack de rede do modem...");
        modem.sendAT("+CFUN=1,1"); 
        return false;
    }
    Serial.println(" OK!");

    client.setServer(MQTT_SERVER, MQTT_PORT);
    client.setBufferSize(4096);
    String clientId = "SIFE_A7670_" + String(esp_random(), HEX);
    
    Serial.print("[MQTT] Broker (ID: ");
    Serial.print(clientId);
    Serial.print(")... ");
    
    bool mqttStatus = false;
    if (String(MQTT_USER).length() > 0) {
        mqttStatus = client.connect(clientId.c_str(), MQTT_USER, MQTT_PASS);
    } else {
        mqttStatus = client.connect(clientId.c_str());
    }

    if (mqttStatus) {
        Serial.println("SUCESSO!");
        return true;
    }
    
    Serial.print("Erro! Codigo (state): ");
    Serial.println(client.state());
    return false;
}

void desconectarRede() {
    if (client.connected()) client.disconnect();
    modem.gprsDisconnect();
    Serial.println("[REDE] 4G Desconectado.");
}

// --- Funções de Envio (JSON) ---
bool enviarBackupVibracao(int sensorID, int indiceTurno, int indiceArrayRTC, AmostraAcelerometro* backupArray) {
    jsonLarge.clear();
    jsonLarge["tipo"] = "BACKUP_RAW";
    jsonLarge["sensor"] = sensorID;
    jsonLarge["turno"] = indiceTurno;
    JsonArray dataX = jsonLarge.createNestedArray("x");
    JsonArray dataY = jsonLarge.createNestedArray("y");
    JsonArray dataZ = jsonLarge.createNestedArray("z");
    for (int i = 0; i < TAMANHO_BACKUP; i++) {
        dataX.add(backupArray[i].x);
        dataY.add(backupArray[i].y);
        dataZ.add(backupArray[i].z);
    }
    size_t n = serializeJson(jsonLarge, mqttMsgBuffer, sizeof(mqttMsgBuffer));
    const char* topic = (sensorID == 1) ? TOPIC_VIBRA_S1_BACKUP : (sensorID == 2 ? TOPIC_VIBRA_S2_BACKUP : TOPIC_VIBRA_S3_BACKUP);
    return client.publish(topic, mqttMsgBuffer, n);
}

bool enviarBackupPressao(int indiceTurno, int indiceArrayRTC) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "BACKUP_PRESSAO";
    jsonSmall["turno"] = indiceTurno;
    jsonSmall["val"] = backupPressao[indiceArrayRTC];
    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));
    return client.publish(TOPIC_PRESSAO_BACKUP, mqttMsgBuffer, n);
}

bool enviarBackupTemperatura(int indiceTurno, int indiceArrayRTC) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "BACKUP_TEMP";
    jsonSmall["turno"] = indiceTurno;
    jsonSmall["val"] = backupTemperatura[indiceArrayRTC];
    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));
    return client.publish(TOPIC_TEMP_BACKUP, mqttMsgBuffer, n);
}

bool enviarVibracaoRealTimeChunked(int sensorID, AmostraAcelerometro* bufferRaw) {
    const int CHUNK_SIZE = 64; // Fatias menores e mais seguras para o 4G
    int totalPartes = NUM_AMOSTRAS / CHUNK_SIZE; 
    
    Serial.printf("\n[MQTT] Preparando Vibracao S%d (%d partes)...\n", sensorID, totalPartes);
    
    for (int parte = 0; parte < totalPartes; parte++) {
        jsonLarge.clear();
        jsonLarge["s"] = sensorID; // "s" = sensor
        jsonLarge["p"] = parte + 1; // "p" = parte
        
        JsonArray dataX = jsonLarge.createNestedArray("x");
        JsonArray dataY = jsonLarge.createNestedArray("y");
        JsonArray dataZ = jsonLarge.createNestedArray("z");
        
        int inicio = parte * CHUNK_SIZE;
        int fim = inicio + CHUNK_SIZE;
        
        for (int i = inicio; i < fim; i++) {
            dataX.add(bufferRaw[i].x);
            dataY.add(bufferRaw[i].y);
            dataZ.add(bufferRaw[i].z);
        }
        
        size_t n = serializeJson(jsonLarge, mqttMsgBuffer, sizeof(mqttMsgBuffer));
        const char* topic = (sensorID == 1) ? TOPIC_VIBRA_S1_REAL : (sensorID == 2 ? TOPIC_VIBRA_S2_REAL : TOPIC_VIBRA_S3_REAL);
        
        Serial.printf("  -> Parte %d/%d (%d bytes): ", parte + 1, totalPartes, n);
        
        // Tenta publicar
        if (client.publish(topic, mqttMsgBuffer, n)) {
            Serial.println("OK");
        } else {
            Serial.println("FALHOU! (Buffer estourou ou rate-limit)");
            return false; // Aborta se der erro para não travar o loop
        }
        
        client.loop();
        esp_task_wdt_reset(); 
        
        // Pausa CRÍTICA de meio segundo para o broker HiveMQ não nos banir por flood
        waitMs(500); 
    }
    return true;
}

bool enviarPressaoRealTime(float medidaVolts) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "REALTIME";
    jsonSmall["val"] = medidaVolts;
    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));
    return client.publish(TOPIC_PRESSAO_REAL, mqttMsgBuffer, n);
}

bool enviarTemperaturaRealTime(float temperatura) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "REALTIME";
    jsonSmall["val"] = temperatura;
    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));
    return client.publish(TOPIC_TEMP_REAL, mqttMsgBuffer, n);
}

bool enviarEnergiaRealTime(float v_fonte, float v_bat, float soc, int rede_ac, bool err_i1, bool err_i2) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "ENERGIA";
    jsonSmall["V_Fonte"] = v_fonte;
    jsonSmall["V_Bat"] = v_bat;
    jsonSmall["SoC"] = soc;
    jsonSmall["RedeAC"] = rede_ac;
    jsonSmall["INA1_Err"] = err_i1; // Novo status
    jsonSmall["INA2_Err"] = err_i2; // Novo status
    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));
    return client.publish("sife_felipe/energia/dados", mqttMsgBuffer, n);
}
#endif