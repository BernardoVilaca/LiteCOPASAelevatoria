#include <Wire.h>
#include <SPI.h>                
#include <Adafruit_ADS1X15.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_ADXL345_U.h>
#include "esp_task_wdt.h"
#include "esp_sleep.h"
#include "Connectar_Desconectar.h"
#include <Adafruit_INA219.h>
#include "SIFE_LIB.h"

// --- Sincronização e Tasks ---
SemaphoreHandle_t busMutex;
SemaphoreHandle_t dataReadySemaphore;
TaskHandle_t TaskSIFE;

// --- Configurações de Hardware ---
#define WDT_TIMEOUT_MS 180000 // 3 minutos 
TwoWire I2C_2 = TwoWire(1);

// Sensores
Adafruit_ADXL345_Unified accel1(12345); // BUS 1 - 0x53
Adafruit_ADXL345_Unified accel2(12346); // BUS 1 - 0x1D
Adafruit_ADXL345_Unified accel3(12347); // BUS 2 - 0x53
Adafruit_ADS1115 ads;                   // BUS 1 - 0x48

// Termopar 
const int thermoSO = 19;  
const int thermoCS = 5;   
const int thermoSCK = 18; 

// --- Variáveis de Operação ---
AmostraAcelerometro bufferSensor1[NUM_AMOSTRAS];
AmostraAcelerometro bufferSensor2[NUM_AMOSTRAS];
AmostraAcelerometro bufferSensor3[NUM_AMOSTRAS];
unsigned long tempoInicioSetup;

// Backup RTC 
RTC_DATA_ATTR AmostraAcelerometro backupSensor1[4][TAMANHO_BACKUP];
RTC_DATA_ATTR AmostraAcelerometro backupSensor2[4][TAMANHO_BACKUP];
RTC_DATA_ATTR AmostraAcelerometro backupSensor3[4][TAMANHO_BACKUP];
RTC_DATA_ATTR float backupPressao[4] = {0.0, 0.0, 0.0, 0.0};
RTC_DATA_ATTR float backupTemperatura[4] = {0.0, 0.0, 0.0, 0.0};
RTC_DATA_ATTR int contBackup = 0;
RTC_DATA_ATTR int conteudo = 0;

const int CICLOS_POR_TURNO = 36; 
bool medidaImportante = false;
float medidaPressaoAtual = 0.0;
float medidaTemperaturaAtual = 0.0;
bool bloqueiaI2C = false;

// --- Funções de Leitura ---
float lerTemperaturaSPI() {
  uint16_t dados;
  
  digitalWrite(thermoCS, LOW); // Ativa o sensor
  delayMicroseconds(1);       
  
  SPI.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
  dados = SPI.transfer16(0x00); 
  SPI.endTransaction();
  
  digitalWrite(thermoCS, HIGH); // Desativa o sensor

  // Verifica se o termopar está desconectado fisicamente (Bit D2 em nível lógico ALTO)
  if (dados & 0x4) {
    return -1.0; 
  }
  
  // Joga fora os 3 bits de controle e status, e multiplica por 0.25 (resolução do MAX6675)
  dados >>= 3;
  return dados * 0.25;
}

float lerTemperaturaFiltrada() {
  const int amostras = 5;
  float leituras[amostras];
  
  // Coleta as 5 amostras rapidamente
  for (int i = 0; i < amostras; i++) {
    leituras[i] = lerTemperaturaSPI();
    vTaskDelay(pdMS_TO_TICKS(10)); 
  }

  // Ordenação simples (Bubble Sort) para encontrar a mediana
  for (int i = 0; i < amostras - 1; i++) {
    for (int j = i + 1; j < amostras; j++) {
      if (leituras[i] > leituras[j]) {
        float temp = leituras[i];
        leituras[i] = leituras[j];
        leituras[j] = temp;
      }
    }
  }

  return leituras[amostras / 2]; 
}

// --- Funções de Suporte ---
void atualizaContador() {
  contBackup++;
  medidaImportante = (contBackup >= CICLOS_POR_TURNO);
  if (medidaImportante) contBackup = 0;
}

void selectBus(TwoWire *bus) {
  if (bus == &I2C_2) { 
    Wire.begin(25, 26); 
    Wire.setClock(10000); 
  } else { 
    Wire.begin(21, 22); 
    Wire.setClock(2000); // Clock lento para os 8 metros
  }
}

void collectSensorSamples(Adafruit_ADXL345_Unified &accel, AmostraAcelerometro *buffer, TwoWire *bus, const char *label) {
  Serial.printf("[SENSOR] Coletando %s...\n", label);
  for (int i = 0; i < NUM_AMOSTRAS; ++i) {
    sensors_event_t e;
    
    xSemaphoreTake(busMutex, portMAX_DELAY);
    if (bus) selectBus(bus);
    accel.getEvent(&e);
    if (bus) selectBus(nullptr);
    xSemaphoreGive(busMutex);

    buffer[i].x = (int16_t)(e.acceleration.x * 100);
    buffer[i].y = (int16_t)(e.acceleration.y * 100);
    buffer[i].z = (int16_t)(e.acceleration.z * 100);
    
    // Alimenta o Watchdog
    if (i % 50 == 0) {
        esp_task_wdt_reset();
        vTaskDelay(pdMS_TO_TICKS(1)); 
    }
  }
}

// --- Task: Gerenciamento de Carga (SIFE) - Core 0 ---
void codigoTaskSIFE(void *parameter) {
  for (;;) {
    // Se o modem estiver tentando conectar, essa task espera
    if (!bloqueiaI2C) {
      if (xSemaphoreTake(busMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        Gerenciamento_Carga();
        xSemaphoreGive(busMutex);
        vTaskDelay(pdMS_TO_TICKS(500)); 
      }
    }
    // Task contínua monitorando a bateria
    vTaskDelay(pdMS_TO_TICKS(100));
  }
}

// --- Task: Leitura de Sensores - Core 1 ---
void taskSensors(void *pv) {
  for (;;) {
    esp_task_wdt_add(NULL);
    
    // 1. Pressão (ADS1115)
    xSemaphoreTake(busMutex, portMAX_DELAY);
    int16_t adc = ads.readADC_SingleEnded(0);
    medidaPressaoAtual = ads.computeVolts(adc) - 0.0024;
    if (medidaPressaoAtual < 0) medidaPressaoAtual = 0.0;
    xSemaphoreGive(busMutex);

    // 2. Vibração (Acelerômetros)
    collectSensorSamples(accel1, bufferSensor1, nullptr, "ADXL #1 (0x53)");
    collectSensorSamples(accel2, bufferSensor2, nullptr, "ADXL #2 (0x1D)");
    collectSensorSamples(accel3, bufferSensor3, &I2C_2, "ADXL #3 (BUS 2)");

    // 3. Temperatura
    medidaTemperaturaAtual = lerTemperaturaFiltrada();
    
    if (medidaTemperaturaAtual < 0) {
        medidaTemperaturaAtual = 0.0; 
    }
    
    Serial.println("[SENSOR] Leituras concluidas. Acordando o 4G...");
    
    // Acorda a taskCommunication
    xSemaphoreGive(dataReadySemaphore);
    esp_task_wdt_delete(NULL);
    
    // A task dorme por 60 segundos até o próximo ciclo de leitura.
    vTaskDelay(pdMS_TO_TICKS(60000)); 
  }
}

// --- Task: Comunicação MQTT (4G) - Core 0 ---
void taskCommunication(void *pv) {
  for (;;) {
    // Fica em estado de bloqueio (dormindo) até o semáforo ser liberado
    if (xSemaphoreTake(dataReadySemaphore, portMAX_DELAY) == pdTRUE) {
      esp_task_wdt_add(NULL); 
      
      bloqueiaI2C = true; 
      bool status = conectarRedeEbroker();
      bloqueiaI2C = false; // RETOMA o SIFE
      
      if (status) {
          enviarPressaoRealTime(medidaPressaoAtual);
          enviarTemperaturaRealTime(medidaTemperaturaAtual);
          enviarEnergiaRealTime(loadvoltage2, loadvoltage1, SoC, fonte, erro_ina1, erro_ina2);
          enviarVibracaoRealTimeChunked(1, bufferSensor1);
          enviarVibracaoRealTimeChunked(2, bufferSensor2);
          enviarVibracaoRealTimeChunked(3, bufferSensor3);

          desconectarRede();
      } 

      if (fonte == 1) {
        Serial.println("[SISTEMA] Ciclo de rede finalizado. O SIFE continua ativo e isolado.");
      } else {
        Serial.println("[SISTEMA] Falta de energia! Entrando em Deep Sleep SIFE...");
        esp_task_wdt_delete(NULL);
        iniciarDeepSleep(); 
      }
      esp_task_wdt_delete(NULL); 
    }
  }
}

void setup() {
  ledcAttachChannel(PWM_PIN, PWM_FREQ, PWM_RESOLUTION, PWM_CHANNEL);
  pinMode(thermoCS, OUTPUT);
  pinMode(MOS, OUTPUT);
  digitalWrite(thermoCS, HIGH); // Mantém o sensor desativado por padrão
  SPI.begin();                  
  tempoInicioSetup = millis();
  Serial.begin(115200);
  
  SerialAT.setRxBufferSize(1024);
  SerialAT.begin(115200, SERIAL_8N1, MODEM_RX, MODEM_TX);

  // Configuração do Watchdog 
  esp_task_wdt_config_t cfg = { 
    .timeout_ms = WDT_TIMEOUT_MS, 
    .idle_core_mask = (1 << 0) | (1 << 1), 
    .trigger_panic = true 
  };
  esp_task_wdt_reconfigure(&cfg);

  busMutex = xSemaphoreCreateMutex();
  dataReadySemaphore = xSemaphoreCreateBinary();

  // Inicializa barramentos I2C
  Wire.begin(21, 22); 
  Wire.setClock(2000); 
  I2C_2.begin(25, 26);
  I2C_2.setClock(10000);

  waitMs(100); 

  xSemaphoreTake(busMutex, portMAX_DELAY);
  init_INA219();
  
  accel1.begin(0x53);
  accel2.begin(0x1D);
  
  selectBus(&I2C_2);
  accel3.begin(0x53);
  selectBus(nullptr);
  
  ads.begin();
  xSemaphoreGive(busMutex);

  xTaskCreatePinnedToCore(codigoTaskSIFE, "TaskSIFE", 4096, NULL, 1, &TaskSIFE, 0);
  xTaskCreatePinnedToCore(taskCommunication, "TaskComms", 12000, NULL, 1, NULL, 0);
  xTaskCreatePinnedToCore(taskSensors, "TaskSensors", 8192, NULL, 2, NULL, 1);

  Serial.println("[SETUP] Sistema SIFE 4G pronto! (Sem Restart Automatico)");
}

void loop() {
  vTaskDelay(portMAX_DELAY);
};