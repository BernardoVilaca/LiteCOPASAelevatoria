#include <Wire.h>
#include <Adafruit_INA219.h>


#define MOS      15 
#define PWM_PIN  12

// Endereços I2C dos sensores INA219
Adafruit_INA219 ina219_1(0x41); // INA de saída do conversor
Adafruit_INA219 ina219_2(0x44); // INA de entrada/bateria


//Configurações Deep sleep
#define SEGUNDOS_PARA_MICROSEGUNDOS 1000000ULL  
#define TEMPO_DE_SONO  30                       


#define PRECHARGE 0
#define CC        1
#define CV        2

void iniciarDeepSleep() {
  esp_sleep_enable_timer_wakeup(TEMPO_DE_SONO * SEGUNDOS_PARA_MICROSEGUNDOS);
  Serial.println("Configurando o ESP32 para dormir por " + String(TEMPO_DE_SONO) + " segundos.");
  Serial.println("Indo dormir agora...");
  Serial.flush(); 
  esp_deep_sleep_start();
}

// --- Parâmetros de PWM (LEDC ESP32) ---

const int PWM_CHANNEL    = 0;
const int PWM_RESOLUTION = 10; 
const int PWM_FREQ       = 50000;  

// --- Variáveis de Controle e Estado ---  
int delei       = 0;
int aumenta = 0, diminui = 0, aux = 0; 
byte binByte    = 0;                   
int Marker = 0;                        
int checkpoint  = 0;

RTC_DATA_ATTR int Bit_Carga = 1023, controlador = 0, fonte = 0, carregou = 0, caiu = 0; 
RTC_DATA_ATTR double coulombs = 0.0;
RTC_DATA_ATTR float SoC = 0.0;
RTC_DATA_ATTR bool erro_ina1 = false;  
RTC_DATA_ATTR bool erro_ina2 = false;  


// --- Parâmetros de Carga e Segurança (float) ---

float Tensao_Alimentar = 14.2; 
float Load_Corrente    = 750.0;
float tolerancia_UP    = 100.0;
float safeLimit        = Load_Corrente + tolerancia_UP; 
float setpoint_inf     = 100.0;

// Shunts e Leituras Reais 
float R_Shunt1 = 0.122, R_Shunt2 = 0.129; 
float realCurrent1 = 0;
float realCurrent2 = 0;
float loadvoltage1 = 0;
float loadvoltage2 = 0;
float safeBatteryV = 14.80; 


// --- Gestão de Energia ---

float capNAmp        = 10;      
float capNAmph       = 1500.0;  
float Coulomb_Bat    = capNAmph * 3.6; 



// --- Temporização e Intervalos (unsigned long) ---

unsigned long tempoAtual      = 0;
unsigned long tempoAnterior   = 0;
unsigned long tempoAnterior2  = 0; 
unsigned long t_cmd           = 0; 
unsigned long t_Trigger       = 0; 
unsigned long lastMillis      = 0;
unsigned long now             = 0; 
unsigned long Timer           = 0;
unsigned long timer_inicio_carga = 0;
unsigned long dormir = 0;

unsigned long intervalo         = 1200; 
unsigned long intervalo2        = 500;  
unsigned long intervalo_Cmd     = 5000; 
unsigned long intervalo_Trigger = 10000;
unsigned long Inter_Timer       = 5000;  
unsigned long Sleep_Timer       = 70000;  
const unsigned long TEMPO_CARENCIA = 5000;


// Função customizada para enviar erros de hardware ao Dashboard
void init_INA219(){
  if (! ina219_1.begin()) {
    Serial.println("Falha no INA219 1 (Bateria)");
    erro_ina1 = true;
  } else {
    Serial.println("INA 219 1 encontrado");
    erro_ina1 = false;
    ina219_1.setCalibration_32V_1A();
  }
  
  if (! ina219_2.begin()) {
    Serial.println("Falha no INA219 2 (Fonte)");
    erro_ina2 = true;
  } else {
    Serial.println("INA 219 2 encontrado");
    erro_ina2 = false;
    ina219_2.setCalibration_32V_1A();
  } 
}

float Arredonda(float v) {
  int dezena = int(v * 10.0f);
  int centesima = (int)(v * 100.0f) % 10;
  if (centesima == 9) dezena += 1;
  else if (centesima == 1) dezena -= 1;
  return dezena / 10.0f;
}

void Controle(int valor){
  if(valor == 1) digitalWrite(MOS , HIGH); 
  else if(valor == 0) digitalWrite(MOS , LOW); 
}

void Monitora(){
  float shuntvoltage1 = 0, shuntvoltage2 = 0;
  float busvoltage1 = 0, busvoltage2 = 0; 
  float power_mW1 = 0, power_mW2 = 0;
  float Rshunt = 0.1, perdas = 0; 
  tempoAtual = millis();
  
  if (tempoAtual - tempoAnterior2 >= intervalo2) {
    tempoAnterior2 = tempoAtual;         
    
    // INA 1 (Bateria)
    shuntvoltage1 = ina219_1.getShuntVoltage_mV();
    busvoltage1 = ina219_1.getBusVoltage_V();
    realCurrent1 = shuntvoltage1/ R_Shunt1;
    perdas = ((realCurrent1/1000)*(Rshunt));
    loadvoltage1 = busvoltage1 + (shuntvoltage1 / 1000) - perdas; 
    power_mW1 = realCurrent1 * loadvoltage1;
    
    // INA 2 (Fonte)
    shuntvoltage2 = ina219_2.getShuntVoltage_mV();
    busvoltage2 = ina219_2.getBusVoltage_V(); 
    realCurrent2 = shuntvoltage2/ R_Shunt2;
    loadvoltage2 = busvoltage2 + (shuntvoltage2 / 1000);
    power_mW2 = realCurrent2 * loadvoltage2;
    
    
    if(realCurrent2 < 10.0 && loadvoltage2 < 11.0){ 
      fonte = 0;
    }else{
      fonte = 1;
    }  
    
    // Debug Serial
    Serial.print("Tensao da FONTE:  "); Serial.print(loadvoltage2); Serial.println(" V");
    Serial.print("Corrente da FONTE:       "); Serial.print(realCurrent2); Serial.println(" mA");
    Serial.print("Tensao na BATERIA:  "); Serial.print(loadvoltage1); Serial.println(" V");
    Serial.print("Corrente na BATERIA:       "); Serial.print(realCurrent1); Serial.println(" mA"); 
    Serial.println(""); 
    
    loadvoltage1 = Arredonda(loadvoltage1);  
  }
}


int chargeState = PRECHARGE;  
float prechargeVoltage = 13.0; // Pré-carga segura até ~13.0 V
float cvVoltage = 14.4;        // Tensão final Constant Voltage

void Pot_dig(){  
  if(loadvoltage1 >= prechargeVoltage && loadvoltage1 <= cvVoltage){
    chargeState = CC;
  }
  tempoAtual = millis(); 
  if (tempoAtual - tempoAnterior >= intervalo && Bit_Carga <= 1023) {  
    tempoAnterior = tempoAtual;     

    switch(chargeState){

      // Fase 0: Pré-carga (Segura)
      case PRECHARGE:
        intervalo2 = 200;   
        intervalo = 400;
        if (loadvoltage1 < prechargeVoltage) {
          if (realCurrent1 > safeLimit) Bit_Carga += 5;
          else Bit_Carga -= 5;
        }else {
          chargeState = CC;
          checkpoint = 0;
        }
        break;

      // Fase 1: Corrente Constante (CC)
      case CC:
        intervalo = 500;
        intervalo2 = 300;
        if (loadvoltage1 < cvVoltage) {
          if (realCurrent1 < Load_Corrente && Bit_Carga > 0) Bit_Carga -= 5;
          else if (realCurrent1 > Load_Corrente) Bit_Carga += 5;
        } else {
          chargeState = CV;
          checkpoint = 0;
        }
        break;

      // Fase 2: Tensão Constante (CV)
      case CV:
        intervalo = 3000;
        intervalo2 = 1500;

        if (loadvoltage1 >= cvVoltage) {
          if (loadvoltage1 > cvVoltage && Bit_Carga > 0) Bit_Carga += 1; 
          else if (loadvoltage1 < cvVoltage) Bit_Carga -= 1; 
        }

        if (realCurrent1 < setpoint_inf) checkpoint = 1; 
        break;
    }
    Serial.print("Estado:"); Serial.print(chargeState);
    Serial.print("  Bit:"); Serial.println(Bit_Carga);
  }
}  

void ContaCoulomb() {
  unsigned long now = millis();
  unsigned long elapsed_ms = now - lastMillis;
  lastMillis = now;

  if (elapsed_ms > 2000 || elapsed_ms == 0) return;

  float shuntV = ina219_1.getShuntVoltage_mV();
  float Corrente_mA = shuntV / R_Shunt1; 
  
  double current_A = (double)Corrente_mA / 1000.0;
  double dt_s = (double)elapsed_ms / 1000.0;
  double deltaCoulomb = abs(current_A * dt_s);

  
  if (Corrente_mA < 0 || fonte == 0) {
    coulombs -= deltaCoulomb;
  } else {
    coulombs += deltaCoulomb;
  }

  
  if (coulombs < 0) coulombs = 0;
  if (coulombs > Coulomb_Bat) coulombs = Coulomb_Bat;

  SoC = (coulombs / Coulomb_Bat) * 100.0;
  double mAh_restante = (coulombs / 3600.0) * 1000.0;

  if (millis() - Timer >= Inter_Timer) {
    Timer = millis();
    Serial.print("Modo: "); Serial.print(fonte == 0 ? "DESCARGA" : "CARGA");
    Serial.print(" | Corrente: "); Serial.print(Corrente_mA); Serial.print("mA");
    Serial.print(" | Bateria: "); Serial.print(SoC, 2); Serial.println("%");
  }
}

void comandos() {
  switch (controlador) {
    case 0: // DESLIGADO
      Controle(0);
      break;

    case 1: // FONTE DIRETA (BATERIA CHEIA) 
      Controle(0); 
      Bit_Carga = 0;  
      intervalo2 = 5000;
      Monitora();
      break;

    case 2: // CARREGANDO (CC/CV)
      if(delei == 1) delay(3000); 
      delei = 0;
      
      
      if(Marker == 0){
        Bit_Carga = 1020;
        checkpoint = 0;
        Marker = 1;
      } 
      Controle(1);
      Pot_dig();
      Monitora();
      ContaCoulomb(); 
      
      
      if(loadvoltage1 > safeBatteryV && Bit_Carga < 800){ 
        Controle(0);  
        Serial.println("Perigo: Excesso de tensão, protegendo bateria!");                
        coulombs = Coulomb_Bat;      
        carregou = 1;
        controlador = 1;
        Marker = 0;
        checkpoint = 0;
        SoC = 100.0;
      }

      if (millis() - timer_inicio_carga > TEMPO_CARENCIA) { 
        if (realCurrent1 <= setpoint_inf && realCurrent1 > 0.0 && fonte == 1 && checkpoint == 1) {
          Serial.println(">>> Bateria 100%. Mudando para modo Fonte.");
          coulombs = Coulomb_Bat;      
          carregou = 1;
          controlador = 1;
          Marker = 0;
          checkpoint = 0;
          SoC = 100.0;
        }
      }
      break;

    case 3: // MODO BATERIA (SEM REDE) 
       Controle(0);  
       intervalo2 = 5000;
       Bit_Carga = 0;
       Monitora(); 
       if (millis() - dormir > Sleep_Timer) { 
        dormir = millis();
        iniciarDeepSleep();
       }
       break;
  }
}

void Gerenciamento_Carga(){
  comandos();
  ledcWriteChannel(PWM_CHANNEL, Bit_Carga);

  if (fonte == 0) {
      if (controlador != 3) { 
        Serial.println("ALERTA: Fonte OFF. Usando Bateria!");  
        caiu = 1;         
        carregou = 0;     
        controlador = 3;  
        lastMillis = millis(); 
      }
      ContaCoulomb(); 
  }
  else if (fonte == 1 && caiu == 1) {
    Serial.println(">>> Fonte VOLTOU. Iniciando recarga...");
    delei = 1;
    Marker = 0;
    checkpoint = 0;
    caiu = 0;                
    carregou = 0;            
    timer_inicio_carga = millis(); 
    controlador = 2;         
  }
  else if (fonte == 1 && carregou == 0 && controlador != 2) { 
    Serial.println("-----------Iniciando carga!-----------");
    timer_inicio_carga = millis(); 
    controlador = 2;
    Bit_Carga = 1020;
  }
}