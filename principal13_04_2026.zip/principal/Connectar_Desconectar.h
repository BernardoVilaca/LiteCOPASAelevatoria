#ifndef CONNECTAR_DESCONECTAR_H
#define CONNECTAR_DESCONECTAR_H

#define NUM_AMOSTRAS 512      
#define TAMANHO_BACKUP 64     

#include <Arduino.h>
#define TINY_GSM_MODEM_SIM7600 
#include <TinyGsmClient.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <esp_task_wdt.h>

const char apn[]      = "zap.vivo.com.br"; 
const char gprsUser[] = "vivo";
const char gprsPass[] = "vivo";

#define MQTT_SERVER "broker.hivemq.com" 
const int MQTT_PORT = 1883; 

#define TOPIC_VIBRA_S1_REAL   "sife_felipe/vibracao/sensor1/dados"
#define TOPIC_VIBRA_S2_REAL   "sife_felipe/vibracao/sensor2/dados"
#define TOPIC_VIBRA_S3_REAL   "sife_felipe/vibracao/sensor3/dados"
#define TOPIC_PRESSAO_REAL    "sife_felipe/pressao/dados"
#define TOPIC_TEMP_REAL       "sife_felipe/temperatura/dados"

#define SerialAT Serial1 
static TinyGsm modem(SerialAT);
static TinyGsmClient gsmClient(modem);
static PubSubClient client(gsmClient);

static char mqttMsgBuffer[4096];
static StaticJsonDocument<512> jsonSmall;
static DynamicJsonDocument jsonLarge(4096);

typedef struct { int16_t x, y, z; } AmostraAcelerometro;

inline void waitMs(uint32_t ms) { vTaskDelay(pdMS_TO_TICKS(ms)); }

bool conectarRedeEbroker() {
    Serial.println("Sincronizando com a rede celular...");
    if (!modem.restart()) return false;

    if (!modem.waitForNetwork(600000L)) {
        Serial.println("Sem sinal de rede.");
        return false;
    }

    if (!modem.gprsConnect(apn, gprsUser, gprsPass)) {
        Serial.println("Erro ao conectar no APN.");
        return false;
    }
    
    client.setServer(MQTT_SERVER, MQTT_PORT);
    client.setBufferSize(4096);
    String clientId = "SIFE_NODE_" + String(esp_random(), HEX);

    if (client.connect(clientId.c_str())) {
        Serial.println("Conexao com servidor MQTT estabelecida.");
        return true;
    }
    return false;
}

void desconectarRede() {
    if (client.connected()) client.disconnect();
    modem.gprsDisconnect();
    Serial.println("Comunicacao encerrada.");
}

bool enviarVibracaoRealTimeChunked(int sensorID, AmostraAcelerometro* bufferRaw) {
    const int CHUNK_SIZE = 64;
    int totalPartes = NUM_AMOSTRAS / CHUNK_SIZE; 
    
    for (int parte = 0; parte < totalPartes; parte++) {
        jsonLarge.clear();
        jsonLarge["s"] = sensorID;
        jsonLarge["p"] = parte + 1;
        
        JsonArray dataX = jsonLarge.createNestedArray("x");
        JsonArray dataY = jsonLarge.createNestedArray("y");
        JsonArray dataZ = jsonLarge.createNestedArray("z");
        
        for (int i = parte * CHUNK_SIZE; i < (parte * CHUNK_SIZE) + CHUNK_SIZE; i++) {
            dataX.add(bufferRaw[i].x);
            dataY.add(bufferRaw[i].y);
            dataZ.add(bufferRaw[i].z);
        }
        
        size_t n = serializeJson(jsonLarge, mqttMsgBuffer, sizeof(mqttMsgBuffer));
        const char* topic = (sensorID == 1) ? TOPIC_VIBRA_S1_REAL : (sensorID == 2 ? TOPIC_VIBRA_S2_REAL : TOPIC_VIBRA_S3_REAL);
        
        if (!client.publish(topic, mqttMsgBuffer, n)) return false;
        
        client.loop();
        esp_task_wdt_reset();
        waitMs(200); 
    }
    return true;
}

bool enviarPressaoRealTime(float medidaVolts) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "REALTIME";
    jsonSmall["val"] = medidaVolts;
    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));
    return client.publish(TOPIC_PRESSAO_REAL, mqttMsgBuffer, n);
}

bool enviarTemperaturaRealTime(float temperatura) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "REALTIME";
    jsonSmall["val"] = temperatura;
    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));
    return client.publish(TOPIC_TEMP_REAL, mqttMsgBuffer, n);
}

bool enviarEnergiaRealTime(float v_f, float v_b, float i_b, float s, int r, bool e1, bool e2) {
    jsonSmall.clear();
    jsonSmall["tipo"] = "ENERGIA";
    jsonSmall["V_Fonte"] = v_f;
    jsonSmall["V_Bat"] = v_b;
    jsonSmall["I_Bat"] = i_b; 
    jsonSmall["SoC"] = s;
    jsonSmall["RedeAC"] = r;
    jsonSmall["INA1_Err"] = e1; 
    jsonSmall["INA2_Err"] = e2; 
    size_t n = serializeJson(jsonSmall, mqttMsgBuffer, sizeof(mqttMsgBuffer));
    return client.publish("sife_felipe/energia/dados", mqttMsgBuffer, n);
}
#endif