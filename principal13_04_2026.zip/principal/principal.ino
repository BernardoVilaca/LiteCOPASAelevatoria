#include <Wire.h>
#include <SPI.h>                
#include <Adafruit_ADS1X15.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_ADXL345_U.h>
#include "esp_task_wdt.h"
#include "esp_sleep.h"
#include "Connectar_Desconectar.h"
#include <Adafruit_INA219.h>
#include "SIFE_LIB.h"

#define MODEM_RX     16  
#define MODEM_TX     17  
#define MODEM_PWRKEY 4   

SemaphoreHandle_t busMutex;
SemaphoreHandle_t dataReadySemaphore;
TaskHandle_t TaskSIFE;

#define WDT_TIMEOUT_MS 180000 
TwoWire I2C_2 = TwoWire(1);

Adafruit_ADXL345_Unified accel1(12345); 
Adafruit_ADXL345_Unified accel2(12346); 
Adafruit_ADXL345_Unified accel3(12347);
Adafruit_ADS1115 ads;                   

const int thermoSO = 19;
const int thermoCS = 5;   
const int thermoSCK = 18; 

AmostraAcelerometro bufferSensor1[NUM_AMOSTRAS];
AmostraAcelerometro bufferSensor2[NUM_AMOSTRAS];
AmostraAcelerometro bufferSensor3[NUM_AMOSTRAS];

float medidaPressaoAtual = 0.0;
float medidaTemperaturaAtual = 0.0;
bool bloqueiaI2C = false;

float lerTemperaturaSPI() {
  uint16_t dados;
  digitalWrite(thermoCS, LOW);
  SPI.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
  dados = SPI.transfer16(0x00);
  SPI.endTransaction();
  digitalWrite(thermoCS, HIGH);
  if (dados & 0x4) return -1.0; 
  return (dados >> 3) * 0.25;
}

float lerTemperaturaFiltrada() {
  const int amostras = 5;
  float leituras[amostras];
  for (int i = 0; i < amostras; i++) {
    leituras[i] = lerTemperaturaSPI();
    vTaskDelay(125); 
  }
  for (int i = 0; i < amostras - 1; i++) {
    for (int j = i + 1; j < amostras; j++) {
      if (leituras[i] > leituras[j]) {
        float temp = leituras[i];
        leituras[i] = leituras[j];
        leituras[j] = temp;
      }
    }
  }
  return leituras[amostras / 2];
}

void selectBus(TwoWire *bus) {
  if (bus == &I2C_2) { 
    Wire.begin(25, 26); Wire.setClock(10000);
  } else { 
    Wire.begin(21, 22); Wire.setClock(2000);
  }
}

void collectSensorSamples(Adafruit_ADXL345_Unified &accel, AmostraAcelerometro *buffer, TwoWire *bus) {
  for (int i = 0; i < NUM_AMOSTRAS; ++i) {
    sensors_event_t e;
    xSemaphoreTake(busMutex, portMAX_DELAY);
    if (bus) selectBus(bus);
    accel.getEvent(&e);
    if (bus) selectBus(nullptr);
    xSemaphoreGive(busMutex);
    buffer[i].x = (int16_t)(e.acceleration.x * 100);
    buffer[i].y = (int16_t)(e.acceleration.y * 100);
    buffer[i].z = (int16_t)(e.acceleration.z * 100);
    if (i % 100 == 0) {
        esp_task_wdt_reset();
        vTaskDelay(pdMS_TO_TICKS(1));
    }
  }
}

void codigoTaskSIFE(void *parameter) {
  for (;;) {
    if (!bloqueiaI2C) {
      if (xSemaphoreTake(busMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        Gerenciamento_Carga();
        xSemaphoreGive(busMutex);
        vTaskDelay(pdMS_TO_TICKS(500)); 
      }
    }
    vTaskDelay(pdMS_TO_TICKS(100));
  }
}

void taskSensors(void *pv) {
  for (;;) {
    esp_task_wdt_add(NULL);
    xSemaphoreTake(busMutex, portMAX_DELAY);
    int16_t adc = ads.readADC_SingleEnded(0);
    medidaPressaoAtual = ads.computeVolts(adc) - 0.0024;
    if (medidaPressaoAtual < 0) medidaPressaoAtual = 0.0;
    xSemaphoreGive(busMutex);

    collectSensorSamples(accel1, bufferSensor1, nullptr);
    collectSensorSamples(accel2, bufferSensor2, nullptr);
    collectSensorSamples(accel3, bufferSensor3, &I2C_2);
    
    medidaTemperaturaAtual = lerTemperaturaFiltrada();
    if (medidaTemperaturaAtual < 0) medidaTemperaturaAtual = 0.0;
    
    xSemaphoreGive(dataReadySemaphore);
    esp_task_wdt_delete(NULL);
    
  vTaskDelay(pdMS_TO_TICKS(1000));
  }
}

void taskCommunication(void *pv) {
  for (;;) {
    if (xSemaphoreTake(dataReadySemaphore, portMAX_DELAY) == pdTRUE) {
      esp_task_wdt_add(NULL);
      bloqueiaI2C = true;
      bool status = conectarRedeEbroker();
      bloqueiaI2C = false;
      
      if (status) {
          enviarPressaoRealTime(medidaPressaoAtual);
          enviarTemperaturaRealTime(medidaTemperaturaAtual);
          enviarEnergiaRealTime(loadvoltage2, loadvoltage1, realCurrent1, SoC, fonte, erro_ina1, erro_ina2);
          enviarVibracaoRealTimeChunked(1, bufferSensor1);
          enviarVibracaoRealTimeChunked(2, bufferSensor2);
          enviarVibracaoRealTimeChunked(3, bufferSensor3);
          desconectarRede();
      } 


      esp_task_wdt_delete(NULL); 
      iniciarDeepSleep();
    }
  }
}

void setup() {
  ledcAttachChannel(PWM_PIN, PWM_FREQ, PWM_RESOLUTION, PWM_CHANNEL);
  pinMode(thermoCS, OUTPUT);
  pinMode(MOS, OUTPUT);
  digitalWrite(thermoCS, HIGH);
  SPI.begin();                  
  
  Serial.begin(115200);
  
  pinMode(MODEM_PWRKEY, OUTPUT);
  digitalWrite(MODEM_PWRKEY, HIGH);
  delay(100);
  digitalWrite(MODEM_PWRKEY, LOW);
  delay(1000);
  digitalWrite(MODEM_PWRKEY, HIGH);
  Serial1.begin(115200, SERIAL_8N1, MODEM_RX, MODEM_TX);

  esp_task_wdt_config_t cfg = { 
    .timeout_ms = WDT_TIMEOUT_MS, 
    .idle_core_mask = (1 << 0) | (1 << 1), 
    .trigger_panic = true 
  };
  esp_task_wdt_reconfigure(&cfg);

  busMutex = xSemaphoreCreateMutex();
  dataReadySemaphore = xSemaphoreCreateBinary();
  Wire.begin(21, 22); 
  Wire.setClock(2000); 
  I2C_2.begin(25, 26);
  I2C_2.setClock(10000);

  waitMs(100); 

  xSemaphoreTake(busMutex, portMAX_DELAY);
  init_INA219();
  accel1.begin(0x53);
  accel2.begin(0x1D);
  selectBus(&I2C_2);
  accel3.begin(0x53);
  selectBus(nullptr);
  ads.begin();
  xSemaphoreGive(busMutex);

  xTaskCreatePinnedToCore(codigoTaskSIFE, "TaskSIFE", 4096, NULL, 1, &TaskSIFE, 0);
  xTaskCreatePinnedToCore(taskCommunication, "TaskComms", 12000, NULL, 1, NULL, 0);
  xTaskCreatePinnedToCore(taskSensors, "TaskSensors", 8192, NULL, 2, NULL, 1);
}

void loop() {
  vTaskDelay(portMAX_DELAY);
}