#include <Wire.h>
#include <Adafruit_INA219.h>

#define MOS      15 
#define PWM_PIN  12

Adafruit_INA219 ina219_1(0x41); 
Adafruit_INA219 ina219_2(0x44); 

#define SEGUNDOS_PARA_MICROSEGUNDOS 1000000ULL  
#define TEMPO_ENVIO_AC       600    
#define TEMPO_ENVIO_BATERIA  1200   

#define PRECHARGE 0
#define CC        1
#define CV        2

const int PWM_CHANNEL    = 0;
const int PWM_RESOLUTION = 10; 
const int PWM_FREQ       = 50000;  

int delei       = 0;
int aumenta = 0, diminui = 0, aux = 0; 
byte binByte    = 0;                   
int Marker = 0;                        
int checkpoint  = 0;

int Bit_Carga = 1023;
int chargeState = PRECHARGE;

RTC_DATA_ATTR int controlador = 0, fonte = 0, carregou = 0, caiu = 0; 
RTC_DATA_ATTR double coulombs = 0.0;
RTC_DATA_ATTR float SoC = 0.0;
RTC_DATA_ATTR bool erro_ina1 = false;  
RTC_DATA_ATTR bool erro_ina2 = false;  

float Load_Corrente    = 750.0;
float tolerancia_UP    = 100.0;
float safeLimit        = Load_Corrente + tolerancia_UP; 
float setpoint_inf     = 100.0;

float R_Shunt1 = 0.122, R_Shunt2 = 0.129;  
float realCurrent1 = 0;
float realCurrent2 = 0;
float loadvoltage1 = 0;
float loadvoltage2 = 0;
float tensaoShutdown      = 11.2;
float tensaoReinicioCarga = 13.2;  
float safeBatteryV        = 14.80; 

float capNAmp        = 10;      
float capNAmph       = 1500.0;  
float Coulomb_Bat    = capNAmph * 3.6; 

unsigned long tempoAtual      = 0;
unsigned long tempoAnterior   = 0;
unsigned long tempoAnterior2  = 0; 
unsigned long t_cmd           = 0; 
unsigned long t_Trigger       = 0; 
unsigned long lastMillis      = 0;
unsigned long Timer           = 0;
unsigned long timer_inicio_carga = 0;
unsigned long dormir          = 0;
unsigned long t_estabiliza    = 0;  

unsigned long intervalo         = 1200; 
unsigned long intervalo2        = 500;  
unsigned long Inter_Timer       = 5000;  
const unsigned long TEMPO_CARENCIA = 5000;

void init_INA219(){
  if (!ina219_1.begin()) {
    Serial.println("Falha no sensor da bateria (INA1)");
    erro_ina1 = true;
  } else {
    erro_ina1 = false;
    ina219_1.setCalibration_32V_1A();
  }
  
  if (!ina219_2.begin()) {
    Serial.println("Falha no sensor da fonte (INA2)");
    erro_ina2 = true;
  } else {
    erro_ina2 = false;
    ina219_2.setCalibration_32V_1A();
  } 
}

void iniciarDeepSleep() { 
  if(loadvoltage1 <= tensaoShutdown){
    Serial.println("Carga critica. Hibernando ate retorno da rede.");
  } else {
    // Escolhe o tempo com base na fonte de energia (AC ou Bateria)
    uint64_t t_sleep = (fonte == 1) ? TEMPO_ENVIO_AC : TEMPO_ENVIO_BATERIA;
    esp_sleep_enable_timer_wakeup(t_sleep * SEGUNDOS_PARA_MICROSEGUNDOS);
    Serial.printf("Entrando em Deep Sleep por %llu segundos.\n", t_sleep);
  }
  Serial.flush();
  esp_deep_sleep_start();
}

float Arredonda(float v) {
  int dezena = int(v * 10.0f);
  int centesima = (int)(v * 100.0f) % 10;
  if (centesima == 9) dezena += 1;
  else if (centesima == 1) dezena -= 1;
  return dezena / 10.0f;
}

void Controle(int valor){
  if(valor == 1) digitalWrite(MOS, HIGH); 
  else if(valor == 0) digitalWrite(MOS, LOW); 
}

void Monitora(){
  float shuntvoltage1 = 0, shuntvoltage2 = 0;
  float busvoltage1 = 0, busvoltage2 = 0; 
  float Rshunt = 0.1, perdas = 0; 
  tempoAtual = millis();
  
  if (tempoAtual - tempoAnterior2 >= intervalo2) {
    tempoAnterior2 = tempoAtual;         
    
    shuntvoltage1 = ina219_1.getShuntVoltage_mV();
    busvoltage1 = ina219_1.getBusVoltage_V();
    realCurrent1 = shuntvoltage1 / R_Shunt1;
    perdas = ((realCurrent1 / 1000) * (Rshunt));
    loadvoltage1 = busvoltage1 + (shuntvoltage1 / 1000) - perdas; 
    
    shuntvoltage2 = ina219_2.getShuntVoltage_mV();
    busvoltage2 = ina219_2.getBusVoltage_V(); 
    realCurrent2 = shuntvoltage2 / R_Shunt2;
    loadvoltage2 = busvoltage2 + (shuntvoltage2 / 1000);
    
    fonte = (realCurrent2 < 10.0 && loadvoltage2 < 11.0) ? 0 : 1;
    loadvoltage1 = Arredonda(loadvoltage1);  
  }
}

void Pot_dig(){
  tempoAtual = millis(); 
  if (tempoAtual - tempoAnterior >= intervalo && Bit_Carga <= 1023) {  
    tempoAnterior = tempoAtual;

    if(loadvoltage1 < 12.5){
      chargeState = PRECHARGE;
    }

    switch(chargeState){
      case PRECHARGE:
        intervalo2 = 200; intervalo = 400;
        if (loadvoltage1 < 13.0) {
          if (realCurrent1 > safeLimit) Bit_Carga += 2;
          else Bit_Carga -= 2;
        } else {
          chargeState = CC;
          checkpoint = 0;
        }
        break;

      case CC:
        intervalo = 600; intervalo2 = 400;
        if (loadvoltage1 < 14.4) {
          if (realCurrent1 < Load_Corrente && Bit_Carga > 0) Bit_Carga -= 2;
          else if (realCurrent1 > Load_Corrente) Bit_Carga += 2;
        } else {
          chargeState = CV;
          checkpoint = 0;
        }
        break;

      case CV:
        intervalo = 3000; intervalo2 = 1500;
        if (loadvoltage1 >= 14.4) {
          if (loadvoltage1 > 14.4 && Bit_Carga > 0) Bit_Carga += 1; 
          else if (loadvoltage1 < 14.4) Bit_Carga -= 1; 
        }
        if (realCurrent1 < setpoint_inf) checkpoint = 1; 
        break;
    }
  }
}  

void ContaCoulomb() {
  unsigned long now = millis();
  unsigned long elapsed_ms = now - lastMillis;
  lastMillis = now;

  if (elapsed_ms > 2000 || elapsed_ms == 0) return;

  float Corrente_mA = ina219_1.getShuntVoltage_mV() / R_Shunt1; 
  double current_A = (double)Corrente_mA / 1000.0;
  double dt_s = (double)elapsed_ms / 1000.0;
  double deltaCoulomb = abs(current_A * dt_s);

  if (Corrente_mA < 0 || fonte == 0) coulombs -= deltaCoulomb;
  else coulombs += deltaCoulomb;

  if (coulombs < 0) coulombs = 0;
  if (coulombs > Coulomb_Bat) coulombs = Coulomb_Bat;

  SoC = (coulombs / Coulomb_Bat) * 100.0;

  if (millis() - Timer >= Inter_Timer) {
    Timer = millis();
    Serial.printf("Carga: %.2f%% | Corrente: %.1fmA | Fonte: %s\n", SoC, Corrente_mA, fonte ? "ON" : "OFF");
  }
}

void comandos() {
  switch (controlador) {
    case 0: 
      Controle(0);
      break;

    case 1: 
      Controle(0); Bit_Carga = 0; intervalo2 = 5000;
      Monitora();
      break;

    case 2: 
      if (delei == 1) {
        if (millis() - timer_inicio_carga < 3000) {
          Controle(0);
          break; 
        } else {
          delei = 0;
          timer_inicio_carga = millis(); 
        }
      }

      if(Marker == 0){
        Bit_Carga = 1020; checkpoint = 0; Marker = 1;
      } 
      Controle(1);
      Pot_dig();
      Monitora();
      ContaCoulomb(); 
      
      if(loadvoltage1 > safeBatteryV && Bit_Carga < 800){ 
        Controle(0);                  
        coulombs = Coulomb_Bat; carregou = 1; controlador = 1; Marker = 0; SoC = 100.0;
      }

      if (millis() - timer_inicio_carga > TEMPO_CARENCIA) { 
        if (realCurrent1 <= setpoint_inf && realCurrent1 > 0.0 && fonte == 1 && checkpoint == 1) {
          coulombs = Coulomb_Bat; carregou = 1; controlador = 1; Marker = 0; SoC = 100.0;
        }
      }
      break;

    case 3: 
      Controle(0); intervalo2 = 5000; Bit_Carga = 0;
      Monitora();
      break;
  }
}

void Gerenciamento_Carga(){
  comandos();
  if (Bit_Carga > 1023) Bit_Carga = 1023;
  if (Bit_Carga < 0)    Bit_Carga = 0;
  ledcWriteChannel(PWM_CHANNEL, Bit_Carga);

  if (fonte == 0) {
    if (controlador != 3) { 
      caiu = 1; carregou = 0; controlador = 3; lastMillis = millis(); 
    }
    ContaCoulomb(); 
  }
  else if (fonte == 1 && caiu == 1) {
    delei = 1; Marker = 0; checkpoint = 0; caiu = 0; carregou = 0;
    timer_inicio_carga = millis(); controlador = 2;
  }
  else if (fonte == 1 && carregou == 1 && controlador == 1) {
    if (loadvoltage1 < tensaoReinicioCarga) {
      if (t_estabiliza == 0) t_estabiliza = millis();
      if (millis() - t_estabiliza > 15000) { 
        carregou = 0; controlador = 2; Marker = 0; delei = 1;
        timer_inicio_carga = millis(); t_estabiliza = 0;
        if (SoC > 95.0) SoC = 95.0; 
      }
    } else t_estabiliza = 0;
  }
  else if (fonte == 1 && carregou == 0 && controlador != 2) { 
    timer_inicio_carga = millis(); controlador = 2; Bit_Carga = 1020; delei = 1;
  }
}